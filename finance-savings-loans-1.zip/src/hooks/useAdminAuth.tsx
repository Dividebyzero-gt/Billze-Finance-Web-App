import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { checkAdminAuth, adminLogout as logoutAdmin } from '@/lib/admin-auth';

export const useAdminAuth = () => {
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const navigate = useNavigate();

  useEffect(() => {
    const verifyAdminAuth = () => {
      setIsLoading(true);
      try {
        const isAuthenticated = checkAdminAuth();
        setIsAdmin(isAuthenticated);
      } catch (error) {
        console.error('Admin auth check error:', error);
        setIsAdmin(false);
      } finally {
        setIsLoading(false);
      }
    };

    verifyAdminAuth();
  }, []);

  const adminLogout = () => {
    logoutAdmin();
    setIsAdmin(false);
    navigate('/admin/login');
  };

  return { isAdmin, isLoading, adminLogout };
};
