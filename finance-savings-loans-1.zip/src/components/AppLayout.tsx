import React from 'react';
import { Outlet } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { Sidebar } from '@/components/ui/sidebar';
import { Header } from '@/components/dashboard/Header';

interface AppLayoutProps {
  children?: React.ReactNode;
  title?: string;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children, title = 'Dashboard' }) => {
  const { sidebarOpen } = useAppContext();

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      
      <div className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'md:ml-64' : ''}`}>
        <Header title={title} />
        
        <main className="p-4 md:p-6">
          <div className="max-w-7xl mx-auto">
            {children || <Outlet />}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
