import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';

export const TransferSettings = () => {
  // Mock settings state
  const [settings, setSettings] = useState({
    enableTransfers: true,
    internalTransfers: true,
    externalTransfers: true,
    internationalTransfers: false,
    dailyTransferLimit: 10000,
    transactionFee: 0.5,
    requireOTP: true,
    instantTransfers: true,
    scheduledTransfers: true,
    recurringTransfers: true,
    transferCutoffTime: '16:00', // 4 PM
    weekendTransfers: false,
  });

  const handleToggle = (setting: string) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting as keyof typeof prev]
    }));
  };

  const handleInputChange = (setting: string, value: string | number) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transfer Settings</CardTitle>
        <CardDescription>Configure money transfer services and limits</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="enable-transfers">Enable Transfers</Label>
            <p className="text-sm text-gray-500">Allow users to transfer money</p>
          </div>
          <Switch
            id="enable-transfers"
            checked={settings.enableTransfers}
            onCheckedChange={() => handleToggle('enableTransfers')}
          />
        </div>
        
        <Separator />
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="internal-transfers">Internal Transfers</Label>
            <p className="text-sm text-gray-500">Allow transfers between accounts in the same bank</p>
          </div>
          <Switch
            id="internal-transfers"
            checked={settings.internalTransfers}
            onCheckedChange={() => handleToggle('internalTransfers')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="external-transfers">External Transfers</Label>
            <p className="text-sm text-gray-500">Allow transfers to other banks</p>
          </div>
          <Switch
            id="external-transfers"
            checked={settings.externalTransfers}
            onCheckedChange={() => handleToggle('externalTransfers')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="international-transfers">International Transfers</Label>
            <p className="text-sm text-gray-500">Allow international money transfers</p>
          </div>
          <Switch
            id="international-transfers"
            checked={settings.internationalTransfers}
            onCheckedChange={() => handleToggle('internationalTransfers')}
          />
        </div>
        
        <Separator />
        
        <div className="space-y-2">
          <Label htmlFor="daily-limit">Daily Transfer Limit</Label>
          <Input
            id="daily-limit"
            type="number"
            value={settings.dailyTransferLimit}
            onChange={(e) => handleInputChange('dailyTransferLimit', parseInt(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="transaction-fee">Transaction Fee (%)</Label>
          <Input
            id="transaction-fee"
            type="number"
            step="0.1"
            value={settings.transactionFee}
            onChange={(e) => handleInputChange('transactionFee', parseFloat(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="cutoff-time">Transfer Cutoff Time</Label>
          <Input
            id="cutoff-time"
            type="time"
            value={settings.transferCutoffTime}
            onChange={(e) => handleInputChange('transferCutoffTime', e.target.value)}
          />
        </div>
        
        <Separator />
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="require-otp">Require OTP Verification</Label>
            <p className="text-sm text-gray-500">Require one-time password for transfers</p>
          </div>
          <Switch
            id="require-otp"
            checked={settings.requireOTP}
            onCheckedChange={() => handleToggle('requireOTP')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="instant-transfers">Instant Transfers</Label>
            <p className="text-sm text-gray-500">Process transfers instantly</p>
          </div>
          <Switch
            id="instant-transfers"
            checked={settings.instantTransfers}
            onCheckedChange={() => handleToggle('instantTransfers')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="scheduled-transfers">Scheduled Transfers</Label>
            <p className="text-sm text-gray-500">Allow users to schedule future transfers</p>
          </div>
          <Switch
            id="scheduled-transfers"
            checked={settings.scheduledTransfers}
            onCheckedChange={() => handleToggle('scheduledTransfers')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="recurring-transfers">Recurring Transfers</Label>
            <p className="text-sm text-gray-500">Allow users to set up recurring transfers</p>
          </div>
          <Switch
            id="recurring-transfers"
            checked={settings.recurringTransfers}
            onCheckedChange={() => handleToggle('recurringTransfers')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="weekend-transfers">Weekend Transfers</Label>
            <p className="text-sm text-gray-500">Allow transfers during weekends</p>
          </div>
          <Switch
            id="weekend-transfers"
            checked={settings.weekendTransfers}
            onCheckedChange={() => handleToggle('weekendTransfers')}
          />
        </div>
        
        <Button>Save Transfer Settings</Button>
      </CardContent>
    </Card>
  );
};
