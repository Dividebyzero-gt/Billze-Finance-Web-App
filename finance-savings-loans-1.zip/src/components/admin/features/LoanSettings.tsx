import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const LoanSettings = () => {
  // Mock settings state
  const [settings, setSettings] = useState({
    enableLoans: true,
    minimumLoanAmount: 500,
    maximumLoanAmount: 50000,
    baseInterestRate: 8.5,
    loanTermOptions: [3, 6, 12, 24, 36],
    requireCreditCheck: true,
    automaticApproval: false,
    earlyRepaymentFee: 2.0,
    gracePeriodDays: 5,
    enableLoanExtensions: true,
  });

  const handleToggle = (setting: string) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting as keyof typeof prev]
    }));
  };

  const handleInputChange = (setting: string, value: string | number) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Loan Settings</CardTitle>
        <CardDescription>Configure loan services and parameters for users</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="enable-loans">Enable Loans</Label>
            <p className="text-sm text-gray-500">Allow users to apply for loans</p>
          </div>
          <Switch
            id="enable-loans"
            checked={settings.enableLoans}
            onCheckedChange={() => handleToggle('enableLoans')}
          />
        </div>
        
        <Separator />
        
        <div className="space-y-2">
          <Label htmlFor="minimum-loan">Minimum Loan Amount</Label>
          <Input
            id="minimum-loan"
            type="number"
            value={settings.minimumLoanAmount}
            onChange={(e) => handleInputChange('minimumLoanAmount', parseInt(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="maximum-loan">Maximum Loan Amount</Label>
          <Input
            id="maximum-loan"
            type="number"
            value={settings.maximumLoanAmount}
            onChange={(e) => handleInputChange('maximumLoanAmount', parseInt(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="interest-rate">Base Interest Rate (%)</Label>
          <Input
            id="interest-rate"
            type="number"
            step="0.1"
            value={settings.baseInterestRate}
            onChange={(e) => handleInputChange('baseInterestRate', parseFloat(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="grace-period">Grace Period (Days)</Label>
          <Input
            id="grace-period"
            type="number"
            value={settings.gracePeriodDays}
            onChange={(e) => handleInputChange('gracePeriodDays', parseInt(e.target.value))}
          />
        </div>
        
        <Separator />
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="credit-check">Require Credit Check</Label>
            <p className="text-sm text-gray-500">Perform credit check before loan approval</p>
          </div>
          <Switch
            id="credit-check"
            checked={settings.requireCreditCheck}
            onCheckedChange={() => handleToggle('requireCreditCheck')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="auto-approval">Automatic Approval</Label>
            <p className="text-sm text-gray-500">Automatically approve loans that meet criteria</p>
          </div>
          <Switch
            id="auto-approval"
            checked={settings.automaticApproval}
            onCheckedChange={() => handleToggle('automaticApproval')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="loan-extensions">Enable Loan Extensions</Label>
            <p className="text-sm text-gray-500">Allow users to extend loan repayment periods</p>
          </div>
          <Switch
            id="loan-extensions"
            checked={settings.enableLoanExtensions}
            onCheckedChange={() => handleToggle('enableLoanExtensions')}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="early-repayment">Early Repayment Fee (%)</Label>
          <Input
            id="early-repayment"
            type="number"
            step="0.1"
            value={settings.earlyRepaymentFee}
            onChange={(e) => handleInputChange('earlyRepaymentFee', parseFloat(e.target.value))}
          />
        </div>
        
        <Button>Save Loan Settings</Button>
      </CardContent>
    </Card>
  );
};
