import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const AccountManagementSettings = () => {
  // Mock settings state
  const [settings, setSettings] = useState({
    allowAccountCreation: true,
    multipleAccountsPerUser: true,
    accountTypes: ['Savings', 'Checking', 'Investment', 'Fixed Deposit'],
    minimumOpeningBalance: 100,
    requireIDVerification: true,
    allowAccountClosure: true,
    inactivityPeriod: 90, // days before account is marked inactive
    enableStatements: true,
    statementFrequency: 'monthly',
    allowJointAccounts: false,
  });

  const handleToggle = (setting: string) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting as keyof typeof prev]
    }));
  };

  const handleInputChange = (setting: string, value: string | number) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Account Management Settings</CardTitle>
        <CardDescription>Configure account creation and management options</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="allow-account-creation">Allow Account Creation</Label>
            <p className="text-sm text-gray-500">Enable users to create new accounts</p>
          </div>
          <Switch
            id="allow-account-creation"
            checked={settings.allowAccountCreation}
            onCheckedChange={() => handleToggle('allowAccountCreation')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="multiple-accounts">Multiple Accounts Per User</Label>
            <p className="text-sm text-gray-500">Allow users to have multiple accounts</p>
          </div>
          <Switch
            id="multiple-accounts"
            checked={settings.multipleAccountsPerUser}
            onCheckedChange={() => handleToggle('multipleAccountsPerUser')}
          />
        </div>
        
        <Separator />
        
        <div className="space-y-2">
          <Label htmlFor="minimum-balance">Minimum Opening Balance</Label>
          <Input
            id="minimum-balance"
            type="number"
            value={settings.minimumOpeningBalance}
            onChange={(e) => handleInputChange('minimumOpeningBalance', parseInt(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="inactivity-period">Inactivity Period (days)</Label>
          <Input
            id="inactivity-period"
            type="number"
            value={settings.inactivityPeriod}
            onChange={(e) => handleInputChange('inactivityPeriod', parseInt(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="statement-frequency">Statement Frequency</Label>
          <Select 
            value={settings.statementFrequency} 
            onValueChange={(value) => handleInputChange('statementFrequency', value)}
          >
            <SelectTrigger id="statement-frequency">
              <SelectValue placeholder="Select frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="biweekly">Bi-weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Separator />
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="id-verification">Require ID Verification</Label>
            <p className="text-sm text-gray-500">Require identity verification for new accounts</p>
          </div>
          <Switch
            id="id-verification"
            checked={settings.requireIDVerification}
            onCheckedChange={() => handleToggle('requireIDVerification')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="account-closure">Allow Account Closure</Label>
            <p className="text-sm text-gray-500">Allow users to close their accounts</p>
          </div>
          <Switch
            id="account-closure"
            checked={settings.allowAccountClosure}
            onCheckedChange={() => handleToggle('allowAccountClosure')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="enable-statements">Enable Statements</Label>
            <p className="text-sm text-gray-500">Generate account statements for users</p>
          </div>
          <Switch
            id="enable-statements"
            checked={settings.enableStatements}
            onCheckedChange={() => handleToggle('enableStatements')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="joint-accounts">Allow Joint Accounts</Label>
            <p className="text-sm text-gray-500">Enable creation of joint accounts</p>
          </div>
          <Switch
            id="joint-accounts"
            checked={settings.allowJointAccounts}
            onCheckedChange={() => handleToggle('allowJointAccounts')}
          />
        </div>
        
        <Button>Save Account Management Settings</Button>
      </CardContent>
    </Card>
  );
};
