import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const BillPaymentSettings = () => {
  // Mock settings state
  const [settings, setSettings] = useState({
    enableBillPayments: true,
    allowedProviders: ['electricity', 'water', 'internet', 'cable'],
    transactionFee: 1.5,
    maxDailyLimit: 5000,
    requireVerification: true,
    instantProcessing: true,
    receiptGeneration: true,
    billReminders: false,
  });

  const handleToggle = (setting: string) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting as keyof typeof prev]
    }));
  };

  const handleInputChange = (setting: string, value: string | number) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Bill Payment Settings</CardTitle>
        <CardDescription>Configure bill payment services for users</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="enable-bill-payments">Enable Bill Payments</Label>
            <p className="text-sm text-gray-500">Allow users to pay bills through the platform</p>
          </div>
          <Switch
            id="enable-bill-payments"
            checked={settings.enableBillPayments}
            onCheckedChange={() => handleToggle('enableBillPayments')}
          />
        </div>
        
        <Separator />
        
        <div className="space-y-2">
          <Label htmlFor="transaction-fee">Transaction Fee (%)</Label>
          <Input
            id="transaction-fee"
            type="number"
            step="0.1"
            value={settings.transactionFee}
            onChange={(e) => handleInputChange('transactionFee', parseFloat(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="max-daily-limit">Maximum Daily Limit</Label>
          <Input
            id="max-daily-limit"
            type="number"
            value={settings.maxDailyLimit}
            onChange={(e) => handleInputChange('maxDailyLimit', parseInt(e.target.value))}
          />
        </div>
        
        <Separator />
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="require-verification">Require Verification</Label>
            <p className="text-sm text-gray-500">Require additional verification for bill payments</p>
          </div>
          <Switch
            id="require-verification"
            checked={settings.requireVerification}
            onCheckedChange={() => handleToggle('requireVerification')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="instant-processing">Instant Processing</Label>
            <p className="text-sm text-gray-500">Process bill payments instantly</p>
          </div>
          <Switch
            id="instant-processing"
            checked={settings.instantProcessing}
            onCheckedChange={() => handleToggle('instantProcessing')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="receipt-generation">Receipt Generation</Label>
            <p className="text-sm text-gray-500">Generate receipts for bill payments</p>
          </div>
          <Switch
            id="receipt-generation"
            checked={settings.receiptGeneration}
            onCheckedChange={() => handleToggle('receiptGeneration')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="bill-reminders">Bill Reminders</Label>
            <p className="text-sm text-gray-500">Send reminders for upcoming bills</p>
          </div>
          <Switch
            id="bill-reminders"
            checked={settings.billReminders}
            onCheckedChange={() => handleToggle('billReminders')}
          />
        </div>
        
        <Button>Save Bill Payment Settings</Button>
      </CardContent>
    </Card>
  );
};
