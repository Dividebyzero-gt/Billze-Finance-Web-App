import React, { createContext, useContext, useState, ReactNode } from 'react';

type FeatureSettingsContextType = {
  // Bill Payment Settings
  enableBillPayments: boolean;
  transactionFee: number;
  maxDailyLimit: number;
  requireVerification: boolean;
  
  // Loan Settings
  enableLoans: boolean;
  minimumLoanAmount: number;
  maximumLoanAmount: number;
  baseInterestRate: number;
  
  // Account Management Settings
  allowAccountCreation: boolean;
  multipleAccountsPerUser: boolean;
  minimumOpeningBalance: number;
  requireIDVerification: boolean;
  
  // Transfer Settings
  enableTransfers: boolean;
  internalTransfers: boolean;
  externalTransfers: boolean;
  dailyTransferLimit: number;
  
  // Remittance Settings
  enableRemittance: boolean;
  exchangeRateMarkup: number;
  maxRemittanceAmount: number;
  requireRecipientVerification: boolean;
  
  // Update functions
  updateBillPaymentSettings: (settings: Partial<BillPaymentSettings>) => void;
  updateLoanSettings: (settings: Partial<LoanSettings>) => void;
  updateAccountSettings: (settings: Partial<AccountSettings>) => void;
  updateTransferSettings: (settings: Partial<TransferSettings>) => void;
  updateRemittanceSettings: (settings: Partial<RemittanceSettings>) => void;
};

type BillPaymentSettings = {
  enableBillPayments: boolean;
  transactionFee: number;
  maxDailyLimit: number;
  requireVerification: boolean;
};

type LoanSettings = {
  enableLoans: boolean;
  minimumLoanAmount: number;
  maximumLoanAmount: number;
  baseInterestRate: number;
};

type AccountSettings = {
  allowAccountCreation: boolean;
  multipleAccountsPerUser: boolean;
  minimumOpeningBalance: number;
  requireIDVerification: boolean;
};

type TransferSettings = {
  enableTransfers: boolean;
  internalTransfers: boolean;
  externalTransfers: boolean;
  dailyTransferLimit: number;
};

type RemittanceSettings = {
  enableRemittance: boolean;
  exchangeRateMarkup: number;
  maxRemittanceAmount: number;
  requireRecipientVerification: boolean;
};

const FeatureSettingsContext = createContext<FeatureSettingsContextType | undefined>(undefined);

export const FeatureSettingsProvider = ({ children }: { children: ReactNode }) => {
  // Bill Payment Settings
  const [billPaymentSettings, setBillPaymentSettings] = useState({
    enableBillPayments: true,
    transactionFee: 1.5,
    maxDailyLimit: 5000,
    requireVerification: true,
  });

  // Loan Settings
  const [loanSettings, setLoanSettings] = useState({
    enableLoans: true,
    minimumLoanAmount: 500,
    maximumLoanAmount: 50000,
    baseInterestRate: 8.5,
  });

  // Account Management Settings
  const [accountSettings, setAccountSettings] = useState({
    allowAccountCreation: true,
    multipleAccountsPerUser: true,
    minimumOpeningBalance: 100,
    requireIDVerification: true,
  });

  // Transfer Settings
  const [transferSettings, setTransferSettings] = useState({
    enableTransfers: true,
    internalTransfers: true,
    externalTransfers: true,
    dailyTransferLimit: 10000,
  });

  // Remittance Settings
  const [remittanceSettings, setRemittanceSettings] = useState({
    enableRemittance: true,
    exchangeRateMarkup: 2.5,
    maxRemittanceAmount: 5000,
    requireRecipientVerification: true,
  });

  const updateBillPaymentSettings = (settings: Partial<BillPaymentSettings>) => {
    setBillPaymentSettings(prev => ({ ...prev, ...settings }));
  };

  const updateLoanSettings = (settings: Partial<LoanSettings>) => {
    setLoanSettings(prev => ({ ...prev, ...settings }));
  };

  const updateAccountSettings = (settings: Partial<AccountSettings>) => {
    setAccountSettings(prev => ({ ...prev, ...settings }));
  };

  const updateTransferSettings = (settings: Partial<TransferSettings>) => {
    setTransferSettings(prev => ({ ...prev, ...settings }));
  };

  const updateRemittanceSettings = (settings: Partial<RemittanceSettings>) => {
    setRemittanceSettings(prev => ({ ...prev, ...settings }));
  };

  const value = {
    ...billPaymentSettings,
    ...loanSettings,
    ...accountSettings,
    ...transferSettings,
    ...remittanceSettings,
    updateBillPaymentSettings,
    updateLoanSettings,
    updateAccountSettings,
    updateTransferSettings,
    updateRemittanceSettings,
  };

  return (
    <FeatureSettingsContext.Provider value={value}>
      {children}
    </FeatureSettingsContext.Provider>
  );
};

export const useFeatureSettings = () => {
  const context = useContext(FeatureSettingsContext);
  if (context === undefined) {
    throw new Error('useFeatureSettings must be used within a FeatureSettingsProvider');
  }
  return context;
};
