import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const RemittanceSettings = () => {
  // Mock settings state
  const [settings, setSettings] = useState({
    enableRemittance: true,
    supportedCountries: ['USA', 'UK', 'Canada', 'Australia', 'Nigeria', 'Ghana', 'Kenya'],
    exchangeRateMarkup: 2.5,
    maxRemittanceAmount: 5000,
    requireRecipientVerification: true,
    allowCashPickup: true,
    allowBankDeposit: true,
    allowMobileWallet: true,
    remittanceFee: 10,
    trackingEnabled: true,
    recipientNotifications: true,
    senderNotifications: true,
  });

  const handleToggle = (setting: string) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting as keyof typeof prev]
    }));
  };

  const handleInputChange = (setting: string, value: string | number) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Remittance Settings</CardTitle>
        <CardDescription>Configure international remittance services</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="enable-remittance">Enable Remittance</Label>
            <p className="text-sm text-gray-500">Allow users to send money internationally</p>
          </div>
          <Switch
            id="enable-remittance"
            checked={settings.enableRemittance}
            onCheckedChange={() => handleToggle('enableRemittance')}
          />
        </div>
        
        <Separator />
        
        <div className="space-y-2">
          <Label htmlFor="exchange-markup">Exchange Rate Markup (%)</Label>
          <Input
            id="exchange-markup"
            type="number"
            step="0.1"
            value={settings.exchangeRateMarkup}
            onChange={(e) => handleInputChange('exchangeRateMarkup', parseFloat(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="max-amount">Maximum Remittance Amount</Label>
          <Input
            id="max-amount"
            type="number"
            value={settings.maxRemittanceAmount}
            onChange={(e) => handleInputChange('maxRemittanceAmount', parseInt(e.target.value))}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="remittance-fee">Remittance Fee (Flat)</Label>
          <Input
            id="remittance-fee"
            type="number"
            value={settings.remittanceFee}
            onChange={(e) => handleInputChange('remittanceFee', parseInt(e.target.value))}
          />
        </div>
        
        <Separator />
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="recipient-verification">Require Recipient Verification</Label>
            <p className="text-sm text-gray-500">Verify recipient identity before remittance</p>
          </div>
          <Switch
            id="recipient-verification"
            checked={settings.requireRecipientVerification}
            onCheckedChange={() => handleToggle('requireRecipientVerification')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="cash-pickup">Allow Cash Pickup</Label>
            <p className="text-sm text-gray-500">Enable cash pickup option for recipients</p>
          </div>
          <Switch
            id="cash-pickup"
            checked={settings.allowCashPickup}
            onCheckedChange={() => handleToggle('allowCashPickup')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="bank-deposit">Allow Bank Deposit</Label>
            <p className="text-sm text-gray-500">Enable direct bank deposit for recipients</p>
          </div>
          <Switch
            id="bank-deposit"
            checked={settings.allowBankDeposit}
            onCheckedChange={() => handleToggle('allowBankDeposit')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="mobile-wallet">Allow Mobile Wallet</Label>
            <p className="text-sm text-gray-500">Enable mobile wallet transfers for recipients</p>
          </div>
          <Switch
            id="mobile-wallet"
            checked={settings.allowMobileWallet}
            onCheckedChange={() => handleToggle('allowMobileWallet')}
          />
        </div>
        
        <Separator />
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="tracking">Enable Tracking</Label>
            <p className="text-sm text-gray-500">Allow users to track remittance status</p>
          </div>
          <Switch
            id="tracking"
            checked={settings.trackingEnabled}
            onCheckedChange={() => handleToggle('trackingEnabled')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="recipient-notifications">Recipient Notifications</Label>
            <p className="text-sm text-gray-500">Send notifications to recipients</p>
          </div>
          <Switch
            id="recipient-notifications"
            checked={settings.recipientNotifications}
            onCheckedChange={() => handleToggle('recipientNotifications')}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="sender-notifications">Sender Notifications</Label>
            <p className="text-sm text-gray-500">Send status updates to senders</p>
          </div>
          <Switch
            id="sender-notifications"
            checked={settings.senderNotifications}
            onCheckedChange={() => handleToggle('senderNotifications')}
          />
        </div>
        
        <Button>Save Remittance Settings</Button>
      </CardContent>
    </Card>
  );
};
