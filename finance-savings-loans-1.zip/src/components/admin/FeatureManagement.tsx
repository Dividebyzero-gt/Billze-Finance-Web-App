import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BillPaymentSettings } from './features/BillPaymentSettings';
import { LoanSettings } from './features/LoanSettings';
import { AccountManagementSettings } from './features/AccountManagementSettings';
import { TransferSettings } from './features/TransferSettings';
import { RemittanceSettings } from './features/RemittanceSettings';

export const FeatureManagement = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Feature Management</h2>
        <p className="text-muted-foreground">Configure user-facing features and services.</p>
      </div>

      <Tabs defaultValue="accounts" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="accounts">Accounts</TabsTrigger>
          <TabsTrigger value="transfers">Transfers</TabsTrigger>
          <TabsTrigger value="bills">Bill Payments</TabsTrigger>
          <TabsTrigger value="loans">Loans</TabsTrigger>
          <TabsTrigger value="remittance">Remittance</TabsTrigger>
        </TabsList>
        
        <TabsContent value="accounts" className="space-y-4">
          <AccountManagementSettings />
        </TabsContent>
        
        <TabsContent value="transfers" className="space-y-4">
          <TransferSettings />
        </TabsContent>
        
        <TabsContent value="bills" className="space-y-4">
          <BillPaymentSettings />
        </TabsContent>
        
        <TabsContent value="loans" className="space-y-4">
          <LoanSettings />
        </TabsContent>
        
        <TabsContent value="remittance" className="space-y-4">
          <RemittanceSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
};
