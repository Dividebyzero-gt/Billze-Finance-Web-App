import React from 'react';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useSettings } from '@/contexts/SettingsContext';

const LanguageSettings: React.FC = () => {
  const { settings, updateSettings } = useSettings();

  const handleLanguageChange = (value: string) => {
    updateSettings({ language: value });
  };

  const handleCurrencyChange = (value: string) => {
    updateSettings({ currency: value });
  };

  return (
    <Card className="p-6">
      <h2 className="text-lg font-medium mb-4">Language & Region</h2>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="language">Language</Label>
          <Select value={settings.language} onValueChange={handleLanguageChange}>
            <SelectTrigger id="language">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="fr">French</SelectItem>
              <SelectItem value="es">Spanish</SelectItem>
              <SelectItem value="yo">Yoruba</SelectItem>
              <SelectItem value="ig">Igbo</SelectItem>
              <SelectItem value="ha">Hausa</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="currency">Currency Format</Label>
          <Select value={settings.currency} onValueChange={handleCurrencyChange}>
            <SelectTrigger id="currency">
              <SelectValue placeholder="Select currency format" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ngn">Nigerian Naira (₦)</SelectItem>
              <SelectItem value="usd">US Dollar ($)</SelectItem>
              <SelectItem value="eur">Euro (€)</SelectItem>
              <SelectItem value="gbp">British Pound (£)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </Card>
  );
};

export default LanguageSettings;
