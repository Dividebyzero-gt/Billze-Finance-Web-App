import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Eye } from 'lucide-react';
import { useSettings } from '@/contexts/SettingsContext';

const PrivacySettings: React.FC = () => {
  const { settings, updateSettings } = useSettings();

  const handleLoginNotificationsChange = () => {
    updateSettings({ loginNotifications: !settings.loginNotifications });
  };

  const handleTransactionConfirmationChange = () => {
    updateSettings({ transactionConfirmation: !settings.transactionConfirmation });
  };

  const handleHideBalanceChange = () => {
    updateSettings({ hideBalance: !settings.hideBalance });
  };

  return (
    <Card className="p-6">
      <h2 className="text-lg font-medium mb-4">Privacy & Security</h2>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="login-notifications">Login Notifications</Label>
            <p className="text-sm text-muted-foreground">Get notified when someone logs into your account</p>
          </div>
          <Switch 
            id="login-notifications" 
            checked={settings.loginNotifications}
            onCheckedChange={handleLoginNotificationsChange}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="transaction-confirmation">Transaction Confirmation</Label>
            <p className="text-sm text-muted-foreground">Require confirmation for transactions above ₦50,000</p>
          </div>
          <Switch 
            id="transaction-confirmation" 
            checked={settings.transactionConfirmation}
            onCheckedChange={handleTransactionConfirmationChange}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="hide-balance">Hide Account Balance</Label>
            <p className="text-sm text-muted-foreground">Hide your balance on the dashboard</p>
          </div>
          <Switch 
            id="hide-balance" 
            checked={settings.hideBalance}
            onCheckedChange={handleHideBalanceChange}
          />
        </div>
        
        <Button variant="outline" className="w-full mt-2">
          <Eye className="h-4 w-4 mr-2" />
          View Account Activity Log
        </Button>
      </div>
    </Card>
  );
};

export default PrivacySettings;
