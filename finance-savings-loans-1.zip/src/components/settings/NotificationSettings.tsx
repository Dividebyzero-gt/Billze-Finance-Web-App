import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { BellRing } from 'lucide-react';
import { useSettings } from '@/contexts/SettingsContext';

const NotificationSettings: React.FC = () => {
  const { settings, updateSettings } = useSettings();

  const handlePushNotificationsChange = () => {
    updateSettings({ pushNotifications: !settings.pushNotifications });
  };

  const handleEmailNotificationsChange = () => {
    updateSettings({ emailNotifications: !settings.emailNotifications });
  };

  const handleMarketingEmailsChange = () => {
    updateSettings({ marketingEmails: !settings.marketingEmails });
  };

  return (
    <Card className="p-6">
      <h2 className="text-lg font-medium mb-4">Notifications</h2>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="push-notifications">Push Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive push notifications on your device</p>
          </div>
          <Switch 
            id="push-notifications" 
            checked={settings.pushNotifications}
            onCheckedChange={handlePushNotificationsChange}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="email-notifications">Email Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive transaction updates via email</p>
          </div>
          <Switch 
            id="email-notifications" 
            checked={settings.emailNotifications}
            onCheckedChange={handleEmailNotificationsChange}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="marketing-emails">Marketing Emails</Label>
            <p className="text-sm text-muted-foreground">Receive promotional offers and updates</p>
          </div>
          <Switch 
            id="marketing-emails" 
            checked={settings.marketingEmails}
            onCheckedChange={handleMarketingEmailsChange}
          />
        </div>
        
        <Button variant="outline" className="w-full mt-2">
          <BellRing className="h-4 w-4 mr-2" />
          Manage Notification Preferences
        </Button>
      </div>
    </Card>
  );
};

export default NotificationSettings;
