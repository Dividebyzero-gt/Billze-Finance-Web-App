import React from 'react';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Moon, Sun } from 'lucide-react';
import { useSettings } from '@/contexts/SettingsContext';

const AppearanceSettings: React.FC = () => {
  const { settings, updateSettings } = useSettings();

  const handleThemeChange = () => {
    // Toggle between light and dark mode
    const newTheme = settings.theme === 'dark' ? 'light' : 'dark';
    updateSettings({ theme: newTheme });
  };

  const handleSystemThemeChange = () => {
    // Toggle between system and current theme
    const newTheme = settings.theme === 'system' ? 
      (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : 
      'system';
    updateSettings({ theme: newTheme });
  };

  const handleCompactViewChange = () => {
    updateSettings({ compactView: !settings.compactView });
  };

  return (
    <Card className="p-6">
      <h2 className="text-lg font-medium mb-4">Appearance</h2>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="dark-mode">Dark Mode</Label>
            <p className="text-sm text-muted-foreground">Toggle between light and dark themes</p>
          </div>
          <div className="flex items-center space-x-2">
            <Sun className="h-4 w-4 text-muted-foreground" />
            <Switch 
              id="dark-mode" 
              checked={settings.theme === 'dark'}
              onCheckedChange={handleThemeChange}
            />
            <Moon className="h-4 w-4 text-muted-foreground" />
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="system-theme">Use System Theme</Label>
            <p className="text-sm text-muted-foreground">Follow your system's theme settings</p>
          </div>
          <Switch 
            id="system-theme" 
            checked={settings.theme === 'system'}
            onCheckedChange={handleSystemThemeChange}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="compact-view">Compact View</Label>
            <p className="text-sm text-muted-foreground">Reduce spacing in the interface</p>
          </div>
          <Switch 
            id="compact-view" 
            checked={settings.compactView}
            onCheckedChange={handleCompactViewChange}
          />
        </div>
      </div>
    </Card>
  );
};

export default AppearanceSettings;
