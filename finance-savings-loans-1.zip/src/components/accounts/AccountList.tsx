import React from 'react';
import { AccountCard } from './AccountCard';
import { Account } from '@/types/account';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface AccountListProps {
  accounts: Account[];
  onToggleMask: (id: string) => void;
  onSetDefault: (id: string) => void;
  onDelete: (id: string) => void;
}

export const AccountList: React.FC<AccountListProps> = ({ 
  accounts, 
  onToggleMask, 
  onSetDefault,
  onDelete 
}) => {
  if (accounts.length === 0) {
    return (
      <Alert className="mt-4">
        <AlertDescription>
          You don't have any accounts yet. Create your first account to get started.
        </AlertDescription>
      </Alert>
    );
  }

  // Sort accounts to show default first
  const sortedAccounts = [...accounts].sort((a, b) => {
    if (a.isDefault) return -1;
    if (b.isDefault) return 1;
    return 0;
  });

  return (
    <div className="mt-4 space-y-4">
      {sortedAccounts.map(account => (
        <AccountCard
          key={account.id}
          account={account}
          onToggleMask={onToggleMask}
          onSetDefault={onSetDefault}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
};
