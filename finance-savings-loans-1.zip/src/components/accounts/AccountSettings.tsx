import React from 'react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface AccountSettingsProps {
  maskAllAccounts: boolean;
  onToggleMaskAll: () => void;
  hideBalances: boolean;
  onToggleHideBalances: () => void;
}

export const AccountSettings: React.FC<AccountSettingsProps> = ({
  maskAllAccounts,
  onToggleMaskAll,
  hideBalances,
  onToggleHideBalances
}) => {
  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="text-lg">Account Privacy Settings</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="mask-accounts">Mask All Account Numbers</Label>
            <p className="text-sm text-muted-foreground">
              Hide your account numbers from view
            </p>
          </div>
          <Switch
            id="mask-accounts"
            checked={maskAllAccounts}
            onCheckedChange={onToggleMaskAll}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="hide-balances">Hide Account Balances</Label>
            <p className="text-sm text-muted-foreground">
              Prevent others from seeing your account balances
            </p>
          </div>
          <Switch
            id="hide-balances"
            checked={hideBalances}
            onCheckedChange={onToggleHideBalances}
          />
        </div>
      </CardContent>
    </Card>
  );
};
