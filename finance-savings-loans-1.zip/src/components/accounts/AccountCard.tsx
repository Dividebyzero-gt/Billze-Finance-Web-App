import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { EyeIcon, EyeOffIcon, StarIcon } from 'lucide-react';
import { Account } from '@/types/account';

interface AccountCardProps {
  account: Account;
  onToggleMask: (id: string) => void;
  onSetDefault: (id: string) => void;
  onDelete: (id: string) => void;
}

export const AccountCard: React.FC<AccountCardProps> = ({ 
  account, 
  onToggleMask, 
  onSetDefault,
  onDelete 
}) => {
  // Format account number with masking if needed
  const displayAccountNumber = account.isMasked 
    ? `**** **** ${account.accountNumber.slice(-4)}` 
    : account.accountNumber;

  // Format balance with masking if needed
  const displayBalance = account.isMasked 
    ? '****' 
    : new Intl.NumberFormat('en-NG', {
        style: 'currency',
        currency: account.currency,
        minimumFractionDigits: 2
      }).format(account.balance);

  // Format currency symbol
  const currencySymbol = account.currency === 'NGN' ? '₦' : 
                         account.currency === 'USD' ? '$' : 
                         account.currency;

  return (
    <Card className={`mb-4 ${account.isDefault ? 'border-primary' : ''}`}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-semibold text-lg flex items-center">
              {account.accountName}
              {account.isDefault && (
                <StarIcon className="h-4 w-4 ml-2 text-yellow-500 fill-yellow-500" />
              )}
            </h3>
            <p className="text-sm text-muted-foreground">{account.accountType}</p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onToggleMask(account.id)}
            aria-label={account.isMasked ? "Show details" : "Hide details"}
          >
            {account.isMasked ? (
              <EyeIcon className="h-4 w-4" />
            ) : (
              <EyeOffIcon className="h-4 w-4" />
            )}
          </Button>
        </div>
        
        <div className="mt-4">
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Account Number</span>
            <span className="font-medium">{displayAccountNumber}</span>
          </div>
          
          <div className="flex justify-between mt-2">
            <span className="text-sm text-muted-foreground">Balance</span>
            <span className="font-bold text-lg">{displayBalance}</span>
          </div>
        </div>
        
        <div className="mt-4 flex justify-between">
          {!account.isDefault && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onSetDefault(account.id)}
            >
              Set as Default
            </Button>
          )}
          
          {!account.isDefault && (
            <Button 
              variant="destructive" 
              size="sm"
              onClick={() => onDelete(account.id)}
            >
              Delete
            </Button>
          )}
          
          {account.isDefault && (
            <div className="ml-auto">
              <span className="text-xs text-muted-foreground italic">Default Account</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
