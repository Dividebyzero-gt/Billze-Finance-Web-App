import React from 'react';
import { Helmet as ReactHelmet } from 'react-helmet-async';

interface SEOProps {
  title?: string;
  description?: string;
  canonical?: string;
  meta?: Array<{ name: string; content: string }>;
}

export const SEO: React.FC<SEOProps> = ({
  title = 'Banking App',
  description = 'Manage your finances with our secure banking application',
  canonical,
  meta = [],
}) => {
  const defaultTitle = 'Banking App';
  const fullTitle = title === defaultTitle ? title : `${title} | ${defaultTitle}`;
  
  return (
    <ReactHelmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      {canonical && <link rel="canonical" href={canonical} />}
      {meta.map((item, index) => (
        <meta key={index} name={item.name} content={item.content} />
      ))}
    </ReactHelmet>
  );
};
