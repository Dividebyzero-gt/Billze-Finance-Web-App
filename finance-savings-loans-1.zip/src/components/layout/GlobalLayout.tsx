import React from 'react';
import { Outlet } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { Sidebar } from '@/components/ui/sidebar';
import { Header } from '@/components/dashboard/Header';
import { Footer } from '@/components/layout/Footer';

interface GlobalLayoutProps {
  children?: React.ReactNode;
  title?: string;
  showSidebar?: boolean;
}

export function GlobalLayout({ 
  children, 
  title = 'Dashboard',
  showSidebar = true
}: GlobalLayoutProps) {
  const { sidebarOpen } = useAppContext();

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title={title} />
      
      <div className="flex flex-1">
        {showSidebar && <Sidebar />}
        
        <main className={`flex-1 transition-all duration-300 ${showSidebar && sidebarOpen ? 'md:ml-64' : ''}`}>
          <div className="p-4 md:p-6 max-w-7xl mx-auto min-h-[calc(100vh-4rem-3.5rem)]">
            {children || <Outlet />}
          </div>
        </main>
      </div>
      
      <Footer />
    </div>
  );
}

export default GlobalLayout;
