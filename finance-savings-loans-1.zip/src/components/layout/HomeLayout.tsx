import React, { useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { HomeHeader } from '@/components/home/HomeHeader';
import { HomeFooter } from '@/components/home/HomeFooter';

interface HomeLayoutProps {
  children?: React.ReactNode;
}

export function HomeLayout({ children }: HomeLayoutProps) {
  const location = useLocation();

  // Scroll to top when route changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  // Scroll to section if hash is present
  useEffect(() => {
    if (location.hash) {
      const element = document.getElementById(location.hash.substring(1));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [location.hash]);

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <HomeHeader />
      
      <main className="flex-1 w-full">
        {children || <Outlet />}
      </main>
      
      <HomeFooter />
    </div>
  );
}

export default HomeLayout;
