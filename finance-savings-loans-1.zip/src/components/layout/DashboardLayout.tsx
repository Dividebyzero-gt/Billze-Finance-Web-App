import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { FixedSidebar } from '@/components/ui/fixed-sidebar';
import { MobileNav } from '@/components/ui/mobile-nav';

interface DashboardLayoutProps {
  children?: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const location = useLocation();
  
  // Get page title based on current route
  const getPageTitle = () => {
    const path = location.pathname;
    if (path === '/dashboard') return 'Dashboard';
    if (path === '/accounts') return 'Accounts';
    if (path === '/transfers') return 'Transfers';
    if (path === '/bills') return 'Bill Payments';
    if (path === '/remittance') return 'Remittance';
    if (path === '/savings') return 'Savings & Investments';
    if (path === '/loans') return 'Loans & Credit';
    if (path === '/investments') return 'Investments';
    if (path === '/analytics') return 'Analytics';
    if (path === '/profile') return 'My Profile';
    if (path === '/settings') return 'Settings';
    if (path === '/support') return 'Help & Support';
    return 'Dashboard';
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <DashboardHeader title={getPageTitle()} />
      
      <div className="flex flex-1 w-full relative">
        {/* Fixed sidebar for desktop */}
        <FixedSidebar />
        
        {/* Main content area */}
        <main className="flex-1 md:ml-64 w-full transition-all duration-300">
          <div className="p-4 md:p-6 w-full mx-auto min-h-[calc(100vh-4rem)] pb-20 md:pb-6">
            {children || <Outlet />}
          </div>
        </main>
        
        {/* Mobile bottom navigation */}
        <MobileNav />
      </div>
    </div>
  );
}

export default DashboardLayout;
