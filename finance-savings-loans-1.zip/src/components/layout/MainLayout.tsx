import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Header } from '@/components/dashboard/Header';
import { Footer } from '@/components/layout/Footer';
import { Sidebar } from '@/components/ui/sidebar';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

interface MainLayoutProps {
  children?: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const { sidebarOpen, setSidebarOpen, toggleSidebar } = useAppContext();
  const location = useLocation();
  const isMobile = useIsMobile();
  
  // Determine if sidebar should be shown based on the current route
  const isAuthRoute = location.pathname === '/login' || location.pathname === '/register';
  const isHomePage = location.pathname === '/';
  const showSidebar = !isAuthRoute && !isHomePage;
  
  // Get page title based on current route
  const getPageTitle = () => {
    const path = location.pathname;
    if (path === '/') return 'Welcome to Billze';
    if (path === '/login') return 'Login';
    if (path === '/register') return 'Register';
    if (path === '/dashboard') return 'Dashboard';
    if (path === '/transfers') return 'Transfers';
    if (path === '/bills') return 'Bill Payments';
    if (path === '/remittance') return 'Remittance';
    if (path === '/savings') return 'Savings & Investments';
    if (path === '/loans') return 'Loans & Credit';
    if (path === '/profile') return 'My Profile';
    if (path === '/settings') return 'Settings';
    return 'Page Not Found';
  };

  // Close sidebar on route change for mobile
  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false);
    } else {
      // On desktop, keep sidebar open by default
      setSidebarOpen(true);
    }
  }, [location.pathname, setSidebarOpen, isMobile]);

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header title={getPageTitle()} />
      
      <div className="flex flex-1 w-full relative">
        {showSidebar && <Sidebar />}
        
        <main className={`flex-1 w-full transition-all duration-300 ${showSidebar && sidebarOpen ? 'md:ml-64' : ''}`}>
          {/* Sidebar toggle button for mobile */}
          {showSidebar && !sidebarOpen && (
            <Button 
              variant="outline" 
              size="icon" 
              onClick={toggleSidebar}
              className="fixed left-4 top-20 z-40 md:hidden bg-white shadow-md border-gray-200"
            >
              <ChevronRight size={18} />
            </Button>
          )}
          
          <div className="p-4 md:p-6 w-full mx-auto min-h-[calc(100vh-4rem-3.5rem)]">
            {children}
          </div>
        </main>
      </div>
      
      <Footer />
    </div>
  );
}

export default MainLayout;
