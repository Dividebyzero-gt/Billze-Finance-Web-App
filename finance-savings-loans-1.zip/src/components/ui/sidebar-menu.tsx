import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  href?: string;
  active?: boolean;
  onClick?: () => void;
}

export const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  href,
  active,
  onClick,
}) => {
  if (onClick) {
    return (
      <Button
        variant="ghost"
        onClick={onClick}
        className={cn(
          'w-full justify-start gap-3 px-3 py-2 text-gray-500 dark:text-gray-400',
          'hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-100',
          'transition-colors duration-200',
          active && 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-medium'
        )}
      >
        <span className="text-current">{icon}</span>
        <span className="flex-1 text-left">{label}</span>
      </Button>
    );
  }
  
  if (!href) return null;
  
  return (
    <Link to={href} className="block">
      <Button
        variant="ghost"
        className={cn(
          'w-full justify-start gap-3 px-3 py-2 text-gray-500 dark:text-gray-400',
          'hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-100',
          'transition-colors duration-200',
          active && 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-medium'
        )}
      >
        <span className="text-current">{icon}</span>
        <span className="flex-1 text-left">{label}</span>
      </Button>
    </Link>
  );
};

interface SidebarGroupProps {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

export const SidebarGroup: React.FC<SidebarGroupProps> = ({
  icon,
  label,
  children,
  defaultOpen = false,
}) => {
  const [open, setOpen] = React.useState(defaultOpen);
  
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="w-full">
      <CollapsibleTrigger asChild>
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 px-3 py-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <span className="text-current">{icon}</span>
          <span className="flex-1 text-left">{label}</span>
          {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="pl-9 pr-2 py-1 space-y-1">
        {children}
      </CollapsibleContent>
    </Collapsible>
  );
};
