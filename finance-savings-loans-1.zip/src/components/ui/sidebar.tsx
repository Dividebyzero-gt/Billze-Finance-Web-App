import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';
import { Icon } from '@/components/ui/icon';
import { useAuth } from '@/contexts/AuthContext';
import { Separator } from '@/components/ui/separator';
import { useMediaQuery } from '@/hooks/use-mobile';

interface SidebarItemProps {
  icon: string;
  label: string;
  href: string;
  active?: boolean;
  onClick?: () => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  href,
  active,
  onClick,
}) => {
  if (onClick) {
    return (
      <Button
        variant="ghost"
        onClick={onClick}
        className={cn(
          'w-full justify-start gap-3 px-3 py-2 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary transition-colors duration-200',
          active && 'bg-sidebar-accent text-sidebar-primary font-medium'
        )}
      >
        <span className="text-current"><Icon icon={icon} size="sm" /></span>
        <span>{label}</span>
      </Button>
    );
  }
  
  return (
    <Link to={href}>
      <Button
        variant="ghost"
        className={cn(
          'w-full justify-start gap-3 px-3 py-2 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary transition-colors duration-200',
          active && 'bg-sidebar-accent text-sidebar-primary font-medium'
        )}
      >
        <span className="text-current"><Icon icon={icon} size="sm" /></span>
        <span>{label}</span>
      </Button>
    </Link>
  );
};

interface SidebarProps {
  className?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ className }) => {
  const location = useLocation();
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const { logout } = useAuth();
  const isMobile = useMediaQuery('(max-width: 768px)');
  
  const menuItems = [
    { icon: 'home', label: "Home", href: "/dashboard" },
    { icon: 'exchange-alt', label: "Transfers", href: "/transfers" },
    { icon: 'file-invoice', label: "Bill Payments", href: "/bills" },
    { icon: 'globe', label: "Remittance", href: "/remittance" },
    { icon: 'piggy-bank', label: "Savings", href: "/savings" },
    { icon: 'credit-card', label: "Loans", href: "/loans" },
  ];
  
  const accountItems = [
    { icon: 'user', label: "Profile", href: "/profile" },
    { icon: 'cog', label: "Settings", href: "/settings" },
    { icon: 'question-circle', label: "Help & Support", href: "/support" },
  ];

  return (
    <aside
      className={cn(
        'fixed inset-y-0 left-0 z-50 flex flex-col transition-transform duration-300 ease-in-out shadow-md',
        'border-r border-sidebar-border',
        // Mobile: solid background
        isMobile ? 'bg-primary text-white' : 'bg-sidebar-background',
        !sidebarOpen && '-translate-x-full',
        sidebarOpen && 'translate-x-0',
        'w-64',
        className
      )}
    >
      <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-4">
        <h1 className={cn(
          "text-xl font-bold font-poppins",
          isMobile ? "text-white" : "text-primary"
        )}>Billze</h1>
        <Button 
          variant={isMobile ? "outline" : "ghost"} 
          size="icon" 
          onClick={toggleSidebar}
          className={isMobile ? "bg-transparent border-white text-white hover:bg-white/20" : ""}
        >
          <Icon icon="chevron-left" size="sm" />
        </Button>
      </div>
      <nav className="flex-1 overflow-auto p-3">
        <div className="space-y-0.5">
          {menuItems.map((item) => (
            <SidebarItem
              key={item.href}
              icon={item.icon}
              label={item.label}
              href={item.href}
              active={location.pathname === item.href || location.pathname.startsWith(item.href + '/')}
            />
          ))}
        </div>
        
        <Separator className="my-4 bg-sidebar-border" />
        
        <div className="space-y-0.5">
          {accountItems.map((item) => (
            <SidebarItem
              key={item.href}
              icon={item.icon}
              label={item.label}
              href={item.href}
              active={location.pathname === item.href || location.pathname.startsWith(item.href + '/')}
            />
          ))}
        </div>
      </nav>
      <div className="border-t border-sidebar-border p-3">
        <SidebarItem
          icon="sign-out-alt"
          label="Logout"
          href="#"
          onClick={logout}
        />
      </div>
    </aside>
  );
};
