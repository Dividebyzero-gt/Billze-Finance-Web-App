import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Home, ArrowRightLeft, FileText, PiggyBank, CreditCard, User, Menu } from 'lucide-react';

interface MobileNavItemProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  active?: boolean;
}

const MobileNavItem: React.FC<MobileNavItemProps> = ({
  icon,
  label,
  href,
  active,
}) => {
  return (
    <Link 
      to={href} 
      className={cn(
        'flex flex-col items-center justify-center py-2 px-1',
        'text-gray-500 dark:text-gray-400',
        'hover:text-blue-600 dark:hover:text-blue-400',
        active && 'text-blue-600 dark:text-blue-400'
      )}
    >
      <span className="text-current">{icon}</span>
      <span className="text-xs mt-1">{label}</span>
    </Link>
  );
};

export const MobileNav: React.FC = () => {
  const location = useLocation();
  
  const navItems = [
    { icon: <Home size={20} />, label: "Home", href: "/dashboard" },
    { icon: <ArrowRightLeft size={20} />, label: "Transfers", href: "/transfers" },
    { icon: <FileText size={20} />, label: "Bills", href: "/bills" },
    { icon: <PiggyBank size={20} />, label: "Savings", href: "/savings" },
    { icon: <User size={20} />, label: "Profile", href: "/profile" },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 z-50">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => (
          <MobileNavItem
            key={item.href}
            icon={item.icon}
            label={item.label}
            href={item.href}
            active={location.pathname === item.href || location.pathname.startsWith(item.href + '/')}
          />
        ))}
      </div>
    </div>
  );
};
