import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import { library } from '@fortawesome/fontawesome-svg-core';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';
import { fab } from '@fortawesome/free-brands-svg-icons';

// Add all icons to the library
library.add(fas, far, fab);

interface IconProps {
  icon: IconProp;
  className?: string;
  size?: 'xs' | 'sm' | 'lg' | '1x' | '2x' | '3x' | '4x' | '5x';
  spin?: boolean;
  pulse?: boolean;
  border?: boolean;
  fixedWidth?: boolean;
  inverse?: boolean;
  listItem?: boolean;
  flip?: 'horizontal' | 'vertical' | 'both';
  rotation?: 90 | 180 | 270;
  onClick?: () => void;
}

export function Icon({
  icon,
  className = '',
  size,
  spin = false,
  pulse = false,
  border = false,
  fixedWidth = false,
  inverse = false,
  listItem = false,
  flip,
  rotation,
  onClick,
  ...props
}: IconProps & Omit<React.HTMLAttributes<HTMLElement>, 'size'>) {
  return (
    <FontAwesomeIcon
      icon={icon}
      className={className}
      size={size}
      spin={spin}
      pulse={pulse}
      border={border}
      fixedWidth={fixedWidth}
      inverse={inverse}
      listItem={listItem}
      flip={flip}
      rotation={rotation}
      onClick={onClick}
      {...props}
    />
  );
}
