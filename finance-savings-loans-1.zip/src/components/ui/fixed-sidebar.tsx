import React from 'react';
import { useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { SidebarItem, SidebarGroup } from '@/components/ui/sidebar-menu';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/contexts/AuthContext';
import {
  Home,
  ArrowRightLeft,
  FileText,
  Globe,
  PiggyBank,
  CreditCard,
  User,
  Settings,
  HelpCircle,
  LogOut,
  LayoutDashboard,
  Wallet,
  BarChart3,
  DollarSign,
  Landmark,
  Layers
} from 'lucide-react';

interface FixedSidebarProps {
  className?: string;
}

export const FixedSidebar: React.FC<FixedSidebarProps> = ({ className }) => {
  const location = useLocation();
  const { logout } = useAuth();
  
  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  return (
    <aside
      className={cn(
        'hidden md:flex flex-col h-screen fixed left-0 top-0 bottom-0 w-64 z-30',
        'border-r border-gray-200 dark:border-gray-800',
        'bg-white dark:bg-gray-900',
        className
      )}
    >
      <div className="flex h-16 items-center px-6 border-b border-gray-200 dark:border-gray-800">
        <h1 className="text-xl font-bold font-poppins text-blue-600 dark:text-blue-400">Billze</h1>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {/* Main Navigation */}
          <div className="space-y-1">
            <SidebarItem
              icon={<LayoutDashboard size={18} />}
              label="Dashboard"
              href="/dashboard"
              active={isActive('/dashboard')}
            />
            
            <SidebarItem
              icon={<Wallet size={18} />}
              label="Accounts"
              href="/accounts"
              active={isActive('/accounts')}
            />
          </div>
          
          {/* Transactions Group */}
          <div>
            <SidebarGroup 
              icon={<Layers size={18} />} 
              label="Transactions"
              defaultOpen={["/transfers", "/bills", "/remittance"].some(path => isActive(path))}
            >
              <SidebarItem
                icon={<ArrowRightLeft size={18} />}
                label="Transfers"
                href="/transfers"
                active={isActive('/transfers')}
              />
              <SidebarItem
                icon={<FileText size={18} />}
                label="Bill Payments"
                href="/bills"
                active={isActive('/bills')}
              />
              <SidebarItem
                icon={<Globe size={18} />}
                label="Remittance"
                href="/remittance"
                active={isActive('/remittance')}
              />
            </SidebarGroup>
          </div>
          
          {/* Financial Products Group */}
          <div>
            <SidebarGroup 
              icon={<DollarSign size={18} />} 
              label="Financial Products"
              defaultOpen={["/savings", "/loans"].some(path => isActive(path))}
            >
              <SidebarItem
                icon={<PiggyBank size={18} />}
                label="Savings"
                href="/savings"
                active={isActive('/savings')}
              />
              <SidebarItem
                icon={<CreditCard size={18} />}
                label="Loans"
                href="/loans"
                active={isActive('/loans')}
              />
              <SidebarItem
                icon={<Landmark size={18} />}
                label="Investments"
                href="/investments"
                active={isActive('/investments')}
              />
            </SidebarGroup>
          </div>
          
          <SidebarItem
            icon={<BarChart3 size={18} />}
            label="Analytics"
            href="/analytics"
            active={isActive('/analytics')}
          />
          
          <Separator className="my-2 bg-gray-200 dark:bg-gray-800" />
          
          {/* Account Settings */}
          <div className="space-y-1">
            <SidebarItem
              icon={<User size={18} />}
              label="Profile"
              href="/profile"
              active={isActive('/profile')}
            />
            <SidebarItem
              icon={<Settings size={18} />}
              label="Settings"
              href="/settings"
              active={isActive('/settings')}
            />
            <SidebarItem
              icon={<HelpCircle size={18} />}
              label="Help & Support"
              href="/support"
              active={isActive('/support')}
            />
          </div>
        </div>
      </ScrollArea>
      
      <div className="border-t border-gray-200 dark:border-gray-800 p-4">
        <SidebarItem
          icon={<LogOut size={18} />}
          label="Logout"
          onClick={logout}
        />
      </div>
    </aside>
  );
};
