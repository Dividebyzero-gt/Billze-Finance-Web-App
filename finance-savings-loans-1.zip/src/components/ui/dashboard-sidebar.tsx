import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';
import { Home, ArrowRightLeft, FileText, Globe, PiggyBank, CreditCard, User, Settings, HelpCircle, LogOut, ChevronLeft, LayoutDashboard, Wallet, BarChart3 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Separator } from '@/components/ui/separator';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  active?: boolean;
  onClick?: () => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  href,
  active,
  onClick,
}) => {
  if (onClick) {
    return (
      <Button
        variant="ghost"
        onClick={onClick}
        className={cn(
          'w-full justify-start gap-3 px-3 py-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-100 transition-colors duration-200',
          active && 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-medium'
        )}
      >
        <span className="text-current">{icon}</span>
        <span>{label}</span>
      </Button>
    );
  }
  
  return (
    <Link to={href}>
      <Button
        variant="ghost"
        className={cn(
          'w-full justify-start gap-3 px-3 py-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-100 transition-colors duration-200',
          active && 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-medium'
        )}
      >
        <span className="text-current">{icon}</span>
        <span>{label}</span>
      </Button>
    </Link>
  );
};

interface DashboardSidebarProps {
  className?: string;
}

export const DashboardSidebar: React.FC<DashboardSidebarProps> = ({ className }) => {
  const location = useLocation();
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const { logout } = useAuth();
  
  const menuItems = [
    { icon: <LayoutDashboard size={18} />, label: "Dashboard", href: "/dashboard" },
    { icon: <Wallet size={18} />, label: "Accounts", href: "/accounts" },
    { icon: <ArrowRightLeft size={18} />, label: "Transfers", href: "/transfers" },
    { icon: <FileText size={18} />, label: "Bill Payments", href: "/bills" },
    { icon: <Globe size={18} />, label: "Remittance", href: "/remittance" },
    { icon: <PiggyBank size={18} />, label: "Savings", href: "/savings" },
    { icon: <CreditCard size={18} />, label: "Loans", href: "/loans" },
    { icon: <BarChart3 size={18} />, label: "Analytics", href: "/analytics" },
  ];
  
  const accountItems = [
    { icon: <User size={18} />, label: "Profile", href: "/profile" },
    { icon: <Settings size={18} />, label: "Settings", href: "/settings" },
    { icon: <HelpCircle size={18} />, label: "Help & Support", href: "/support" },
  ];

  return (
    <aside
      className={cn(
        'fixed inset-y-0 left-0 z-50 flex flex-col transition-transform duration-300 ease-in-out shadow-md',
        'border-r border-gray-200 dark:border-gray-800',
        'bg-white dark:bg-gray-900',
        !sidebarOpen && '-translate-x-full',
        sidebarOpen && 'translate-x-0',
        'w-64',
        className
      )}
    >
      <div className="flex h-16 items-center justify-between border-b border-gray-200 dark:border-gray-800 px-4">
        <h1 className="text-xl font-bold font-poppins text-blue-600 dark:text-blue-400">Billze</h1>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleSidebar}
          className="text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <ChevronLeft size={18} />
        </Button>
      </div>
      <nav className="flex-1 overflow-auto p-3">
        <div className="space-y-0.5">
          {menuItems.map((item) => (
            <SidebarItem
              key={item.href}
              icon={item.icon}
              label={item.label}
              href={item.href}
              active={location.pathname === item.href || location.pathname.startsWith(item.href + '/')}
            />
          ))}
        </div>
        
        <Separator className="my-4 bg-gray-200 dark:bg-gray-800" />
        
        <div className="space-y-0.5">
          {accountItems.map((item) => (
            <SidebarItem
              key={item.href}
              icon={item.icon}
              label={item.label}
              href={item.href}
              active={location.pathname === item.href || location.pathname.startsWith(item.href + '/')}
            />
          ))}
        </div>
      </nav>
      <div className="border-t border-gray-200 dark:border-gray-800 p-3">
        <SidebarItem
          icon={<LogOut size={18} />}
          label="Logout"
          href="#"
          onClick={logout}
        />
      </div>
    </aside>
  );
};