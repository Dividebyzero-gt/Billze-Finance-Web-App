import React from 'react';
import { Button } from '@/components/ui/button';

interface PricingPlan {
  name: string;
  price: string;
  description: string;
  features: string[];
  buttonText: string;
  popular?: boolean;
}

export const PricingSection: React.FC = () => {
  const plans: PricingPlan[] = [
    {
      name: 'Basic',
      price: 'Free',
      description: 'Perfect for individuals getting started',
      features: [
        'Up to 5 bill payments per month',
        'Basic account management',
        'Mobile app access',
        'Email support'
      ],
      buttonText: 'Get Started'
    },
    {
      name: 'Premium',
      price: '$9.99/mo',
      description: 'Ideal for active users with multiple needs',
      features: [
        'Unlimited bill payments',
        'Multiple account management',
        'Advanced savings tools',
        'Priority customer support',
        'No transaction fees'
      ],
      buttonText: 'Try Premium',
      popular: true
    },
    {
      name: 'Business',
      price: '$19.99/mo',
      description: 'For small businesses and teams',
      features: [
        'Everything in Premium',
        'Team accounts & permissions',
        'Business reporting tools',
        'API access',
        'Dedicated account manager'
      ],
      buttonText: 'Contact Sales'
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-4">Simple, Transparent Pricing</h2>
        <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
          Choose the plan that works best for your needs. All plans come with a 14-day free trial.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`border rounded-lg overflow-hidden ${plan.popular ? 'border-blue-500 shadow-lg' : 'border-gray-200'}`}
            >
              {plan.popular && (
                <div className="bg-blue-500 text-white text-center py-2 text-sm font-medium">
                  Most Popular
                </div>
              )}
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold">{plan.price}</span>
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full ${plan.popular ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-800 hover:bg-gray-900'}`}
                >
                  {plan.buttonText}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
