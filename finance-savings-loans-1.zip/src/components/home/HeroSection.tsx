import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { BG_COLORS, TEXT_COLORS, ACCENT_COLOR } from '@/lib/theme-constants';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons';

export const HeroSection: React.FC = () => {
  return (
    <section className={`relative overflow-hidden bg-gradient-to-r ${BG_COLORS.gradient} text-white py-20 md:py-32 w-full`}>
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-blue-500 opacity-20 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-80 h-80 rounded-full bg-blue-400 opacity-10 blur-3xl"></div>
        <div className="absolute bottom-0 right-1/3 w-64 h-64 rounded-full bg-blue-300 opacity-10 blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 animate-fade-in">
              Banking Made <span className={`text-${ACCENT_COLOR.light}`}>Simple</span> for Nigerians
            </h1>
            <p className="text-xl mb-8 text-blue-100 max-w-lg">
              Experience secure, affordable, and convenient banking services tailored for the Nigerian market.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/register" className="w-full sm:w-auto">
                <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 w-full sm:w-auto shadow-lg hover:shadow-xl transition-all duration-200">
                  Open an Account
                </Button>
              </Link>
              <Link to="/login" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600 w-full sm:w-auto transition-all duration-200">
                  Login
                </Button>
              </Link>
            </div>
            
            {/* Trust indicators with Font Awesome icons */}
            <div className="mt-12 flex items-center space-x-6">
              <div className="flex items-center">
                <FontAwesomeIcon icon={faCheckCircle} className={`h-5 w-5 text-${ACCENT_COLOR.light}`} />
                <span className="ml-2 text-blue-100 text-sm">CBN Regulated</span>
              </div>
              <div className="flex items-center">
                <FontAwesomeIcon icon={faCheckCircle} className={`h-5 w-5 text-${ACCENT_COLOR.light}`} />
                <span className="ml-2 text-blue-100 text-sm">NDIC Insured</span>
              </div>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            {/* Main image with shadow and border */}
            <div className="relative z-10 rounded-lg shadow-2xl overflow-hidden border border-blue-400/30 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm">
              <img 
                src="/digital-banking.jpg" 
                alt="Nigerian Digital Banking Services" 
                className="w-full h-auto rounded-lg transform transition-transform duration-500 hover:scale-105"
                onError={(e) => {
                  // Fallback if image fails to load
                  const target = e.target as HTMLImageElement;
                  target.src = "/nigeria-banking.jpg";
                  target.alt = "Nigerian Banking Services";
                  // Second fallback
                  target.onerror = () => {
                    target.src = "/placeholder.svg";
                    target.alt = "Nigerian Banking App Dashboard";
                    target.onerror = null; // Prevent infinite loop
                  };
                }}
              />
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-blue-500/20 rounded-full blur-xl"></div>
            <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-blue-400/10 rounded-full blur-xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
};
