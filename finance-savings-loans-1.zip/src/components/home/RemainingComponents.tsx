import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Link } from 'react-router-dom';

// AboutSection with Nigerian banking context
export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <img 
              src="/nigeria-banking.jpg" 
              alt="About NaijaPay" 
              className="rounded-lg shadow-lg w-full"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = "/placeholder.svg";
              }}
            />
          </div>
          
          <div className="md:w-1/2">
            <h2 className="text-3xl font-bold mb-6">About NaijaPay</h2>
            <p className="text-gray-600 mb-4">
              Founded in 2023, NaijaPay was created with a simple mission: to make banking services accessible, 
              affordable, and stress-free for all Nigerians.
            </p>
            <p className="text-gray-600 mb-4">
              Our team of financial experts and technology innovators work together to create solutions that 
              help individuals and small businesses across Nigeria take control of their financial lives.
            </p>
            <p className="text-gray-600 mb-6">
              We are fully licensed by the Central Bank of Nigeria (CBN) and all deposits are insured by 
              the Nigeria Deposit Insurance Corporation (NDIC).
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-700 mb-1">500K+</h3>
                <p className="text-sm text-gray-600">Active Users</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-700 mb-1">₦10B+</h3>
                <p className="text-sm text-gray-600">Transactions Processed</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-700 mb-1">36+</h3>
                <p className="text-sm text-gray-600">States Covered</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-700 mb-1">4.8/5</h3>
                <p className="text-sm text-gray-600">Customer Rating</p>
              </div>
            </div>
            
            <Button className="bg-green-600 hover:bg-green-700">
              Learn More About Our Story
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
