import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faTimes } from '@fortawesome/free-solid-svg-icons';

export const HomeHeader: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header 
      className={`sticky top-0 z-30 w-full transition-all duration-300 ${scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <span className={`text-2xl font-bold ${scrolled ? 'text-blue-500' : 'text-blue-300'}`}>NaijaPay</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a 
              href="#features" 
              className={`text-blue-500 hover:text-blue-700 transition-colors`}
            >
              Services
            </a>
            <a 
              href="#pricing" 
              className={`text-blue-500 hover:text-blue-700 transition-colors`}
            >
              Tariffs
            </a>
            <a 
              href="#testimonials" 
              className={`text-blue-500 hover:text-blue-700 transition-colors`}
            >
              Testimonials
            </a>
            <a 
              href="#about" 
              className={`text-blue-500 hover:text-blue-700 transition-colors`}
            >
              About Us
            </a>
            <a 
              href="#contact" 
              className={`text-blue-500 hover:text-blue-700 transition-colors`}
            >
              Contact
            </a>
          </nav>
          
          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/login">
              <Button 
                variant={scrolled ? "outline" : "secondary"} 
                className={scrolled ? `border-blue-500 text-blue-500 hover:bg-blue-50` : `text-blue-500 hover:bg-blue-100`}
              >
                Login
              </Button>
            </Link>
            <Link to="/register">
              <Button className={`bg-blue-500 hover:bg-blue-700 text-white`}>
                Open Account
              </Button>
            </Link>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              type="button"
              className={scrolled ? "text-gray-600 hover:text-blue-600" : "text-white hover:text-blue-200"}
              onClick={toggleMobileMenu}
            >
              {mobileMenuOpen ? (
                <FontAwesomeIcon icon={faTimes} className="h-6 w-6" />
              ) : (
                <FontAwesomeIcon icon={faBars} className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pt-4 border-t border-gray-200 bg-white rounded-lg shadow-lg absolute left-0 right-0 mx-4">
            <nav className="flex flex-col space-y-4 p-4">
              <a 
                href="#features" 
                className={`text-blue-500 hover:text-blue-700`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Services
              </a>
              <a 
                href="#pricing" 
                className={`text-blue-500 hover:text-blue-700`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Tariffs
              </a>
              <a 
                href="#testimonials" 
                className={`text-blue-500 hover:text-blue-700`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Testimonials
              </a>
              <a 
                href="#about" 
                className={`text-blue-500 hover:text-blue-700`}
                onClick={() => setMobileMenuOpen(false)}
              >
                About Us
              </a>
              <a 
                href="#contact" 
                className={`text-blue-500 hover:text-blue-700`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Contact
              </a>
              <div className="flex space-x-4 pt-2">
                <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="outline" className={`border-blue-500 text-blue-500 w-full`}>
                    Login
                  </Button>
                </Link>
                <Link to="/register" onClick={() => setMobileMenuOpen(false)}>
                  <Button className={`bg-blue-500 hover:bg-blue-700 w-full`}>
                    Open Account
                  </Button>
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};
