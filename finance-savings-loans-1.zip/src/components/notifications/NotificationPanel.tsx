import React from 'react';
import { Bell, X, Check, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

type NotificationType = 'transaction' | 'security' | 'system' | 'promo';

interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: NotificationType;
}

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    title: 'Transaction Completed',
    message: 'Your transfer of ₦25,000 to John Doe was successful.',
    time: '2 minutes ago',
    read: false,
    type: 'transaction'
  },
  {
    id: '2',
    title: 'Security Alert',
    message: 'A new device was used to log into your account.',
    time: '1 hour ago',
    read: false,
    type: 'security'
  },
  {
    id: '3',
    title: 'Bill Payment Reminder',
    message: 'Your electricity bill is due in 3 days.',
    time: '3 hours ago',
    read: true,
    type: 'system'
  },
  {
    id: '4',
    title: 'Special Offer',
    message: 'Get 5% cashback on all transactions this weekend!',
    time: '1 day ago',
    read: true,
    type: 'promo'
  },
  {
    id: '5',
    title: 'Loan Approved',
    message: 'Your loan application of ₦100,000 has been approved.',
    time: '2 days ago',
    read: true,
    type: 'transaction'
  }
];

const NotificationItem: React.FC<{ notification: Notification; onMarkAsRead: (id: string) => void }> = ({ 
  notification, 
  onMarkAsRead 
}) => {
  const getTypeColor = (type: NotificationType) => {
    switch (type) {
      case 'transaction': return 'bg-blue-100 text-blue-600';
      case 'security': return 'bg-red-100 text-red-600';
      case 'system': return 'bg-amber-100 text-amber-600';
      case 'promo': return 'bg-green-100 text-green-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className={`p-3 hover:bg-gray-50 transition-colors ${!notification.read ? 'bg-blue-50/30' : ''}`}>
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-full ${getTypeColor(notification.type)}`}>
          {notification.type === 'transaction' && <Bell size={16} />}
          {notification.type === 'security' && <Bell size={16} />}
          {notification.type === 'system' && <Clock size={16} />}
          {notification.type === 'promo' && <Bell size={16} />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start">
            <h4 className={`font-medium text-sm ${!notification.read ? 'text-black' : 'text-gray-700'}`}>
              {notification.title}
            </h4>
            <span className="text-xs text-gray-500">{notification.time}</span>
          </div>
          <p className="text-xs text-gray-600 mt-1 line-clamp-2">{notification.message}</p>
        </div>
        {!notification.read && (
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 rounded-full hover:bg-blue-100 hover:text-blue-600"
            onClick={() => onMarkAsRead(notification.id)}
          >
            <Check size={14} />
          </Button>
        )}
      </div>
    </div>
  );
};

export const NotificationPanel: React.FC<NotificationPanelProps> = ({ isOpen, onClose }) => {
  const [notifications, setNotifications] = React.useState<Notification[]>(mockNotifications);
  
  const unreadCount = notifications.filter(n => !n.read).length;
  
  const handleMarkAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };
  
  const handleMarkAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm">
      <div 
        className="absolute right-0 top-0 h-full w-full max-w-sm bg-white shadow-lg animate-in slide-in-from-right"
      >
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-semibold text-lg">Notifications</h2>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-xs h-8"
                onClick={handleMarkAllAsRead}
              >
                Mark all as read
              </Button>
            )}
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X size={18} />
            </Button>
          </div>
        </div>
        
        <ScrollArea className="h-[calc(100vh-4rem)]">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-center p-4">
              <Bell size={24} className="text-gray-400 mb-2" />
              <p className="text-gray-500">No notifications yet</p>
            </div>
          ) : (
            <div>
              {unreadCount > 0 && (
                <>
                  <div className="p-3 pb-1">
                    <h3 className="text-xs font-medium text-gray-500 uppercase">New</h3>
                  </div>
                  {notifications
                    .filter(n => !n.read)
                    .map(notification => (
                      <NotificationItem 
                        key={notification.id} 
                        notification={notification} 
                        onMarkAsRead={handleMarkAsRead} 
                      />
                    ))}
                  <Separator />
                </>
              )}
              
              <div className="p-3 pb-1">
                <h3 className="text-xs font-medium text-gray-500 uppercase">Earlier</h3>
              </div>
              {notifications
                .filter(n => n.read)
                .map(notification => (
                  <NotificationItem 
                    key={notification.id} 
                    notification={notification} 
                    onMarkAsRead={handleMarkAsRead} 
                  />
                ))}
            </div>
          )}
        </ScrollArea>
      </div>
    </div>
  );
};
