import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { PRIMARY_COLOR } from '@/lib/theme-constants';
import { Icon } from '@/components/ui/icon';

export const ServiceMenu: React.FC = () => {
  const services = [
    {
      id: 'transfers',
      name: 'Transfers',
      description: 'Send money to anyone',
      icon: 'paper-plane',
      link: '/transfers',
    },
    {
      id: 'bills',
      name: 'Bill Payments',
      description: 'Pay for utilities & services',
      icon: 'file-invoice',
      link: '/bills',
    },
    {
      id: 'airtime',
      name: 'Airtime & Data',
      description: 'Recharge any network',
      icon: 'credit-card',
      link: '/bills',
    },
    {
      id: 'loans',
      name: 'Loans',
      description: 'Quick access to funds',
      icon: 'money-bill-wave',
      link: '/loans',
    },
    {
      id: 'savings',
      name: 'Savings',
      description: 'Grow your money',
      icon: 'piggy-bank',
      link: '/savings',
    },
    {
      id: 'remittance',
      name: 'Remittance',
      description: 'International transfers',
      icon: 'globe',
      link: '/remittance',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {services.map((service) => (
        <Link 
          key={service.id} 
          to={service.link} 
          className={`flex flex-col items-center justify-center p-4 rounded-lg border border-gray-200 hover:border-blue-500 hover:shadow-md transition-all duration-200 bg-white group`}
        >
          <div className={`p-3 rounded-full bg-blue-50 text-blue-500 mb-3 group-hover:bg-blue-500 group-hover:text-white transition-all duration-200`}>
            <Icon icon={service.icon} className="h-5 w-5" />
          </div>
          <h3 className="font-medium text-sm text-center">{service.name}</h3>
          <p className="text-xs text-gray-500 text-center mt-1">{service.description}</p>
          <div className={`mt-3 flex items-center text-blue-500 text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-200`}>
            <span>View</span>
            <ArrowRight className="h-3 w-3 ml-1" />
          </div>
        </Link>
      ))}
    </div>
  );
};
