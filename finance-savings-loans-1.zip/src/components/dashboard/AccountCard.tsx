import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';

export const AccountCard: React.FC = () => {
  const [showBalance, setShowBalance] = React.useState(true);

  return (
    <Card className={`bg-gradient-to-r from-blue-500 to-blue-700 text-white overflow-hidden`}>
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-blue-100 mb-1">Available Balance</p>
            <div className="flex items-center space-x-2">
              <h2 className="text-3xl font-bold">
                {showBalance ? '₦2,540,000.00' : '••••••••••'}
              </h2>
              <button 
                onClick={() => setShowBalance(!showBalance)}
                className="text-blue-100 hover:text-white transition-colors"
              >
                {showBalance ? 
                  <Icon icon="eye-slash" className="h-5 w-5" /> : 
                  <Icon icon="eye" className="h-5 w-5" />
                }
              </button>
            </div>
            <p className="text-sm text-blue-100 mt-1">Account Number: 0123456789</p>
          </div>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="border-blue-200 text-white hover:bg-white hover:text-blue-700 transition-all"
          >
            <Icon icon="plus-circle" className="h-4 w-4 mr-1" />
            Fund Account
          </Button>
        </div>
        
        <div className="grid grid-cols-3 gap-4 mt-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <p className="text-xs text-blue-100">Today's Inflow</p>
            <p className="text-lg font-semibold mt-1">+₦250,000.00</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <p className="text-xs text-blue-100">Today's Outflow</p>
            <p className="text-lg font-semibold mt-1">-₦27,500.00</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <p className="text-xs text-blue-100">Pending</p>
            <p className="text-lg font-semibold mt-1">₦0.00</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
