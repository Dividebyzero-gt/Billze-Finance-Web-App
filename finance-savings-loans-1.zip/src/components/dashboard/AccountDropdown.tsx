import React from 'react';
import { ChevronDown, ChevronUp, Eye, EyeOff } from 'lucide-react';
import { Account } from '@/types/account';
import { useAccounts } from '@/contexts/AccountContext';

interface AccountDropdownProps {
  selectedAccount: Account | null;
  onSelectAccount: (account: Account) => void;
  showBalance: boolean;
  toggleBalanceVisibility: () => void;
}

export const AccountDropdown: React.FC<AccountDropdownProps> = ({
  selectedAccount,
  onSelectAccount,
  showBalance,
  toggleBalanceVisibility
}) => {
  const { accounts, toggleMaskAccount } = useAccounts();
  const [isOpen, setIsOpen] = React.useState(false);

  const toggleDropdown = () => setIsOpen(!isOpen);

  const handleSelectAccount = (account: Account) => {
    onSelectAccount(account);
    setIsOpen(false);
  };

  const handleToggleMask = (e: React.MouseEvent, accountId: string) => {
    e.stopPropagation();
    toggleMaskAccount(accountId);
  };

  return (
    <div className="relative">
      <div 
        className="flex items-center justify-between cursor-pointer p-2 rounded-md hover:bg-primary-foreground/10"
        onClick={toggleDropdown}
      >
        <div>
          <p className="text-sm text-primary-foreground/80">
            {selectedAccount?.accountName || 'Select Account'}
          </p>
          <p className="text-xs text-primary-foreground/60">
            {selectedAccount ? (selectedAccount.isMasked ? '••••••' + selectedAccount.accountNumber.slice(-4) : selectedAccount.accountNumber) : ''}
          </p>
        </div>
        {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </div>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-md shadow-lg z-10 max-h-48 overflow-y-auto">
          {accounts.map(account => (
            <div 
              key={account.id}
              className="flex items-center justify-between p-3 hover:bg-gray-100 cursor-pointer"
              onClick={() => handleSelectAccount(account)}
            >
              <div>
                <p className="font-medium">{account.accountName}</p>
                <p className="text-sm text-gray-600">
                  {account.isMasked ? '••••••' + account.accountNumber.slice(-4) : account.accountNumber}
                </p>
                <p className="text-sm font-semibold">
                  {account.currency} {showBalance ? account.balance.toLocaleString() : '••••••'}
                </p>
              </div>
              <button
                onClick={(e) => handleToggleMask(e, account.id)}
                className="p-1 hover:bg-gray-200 rounded-full"
              >
                {account.isMasked ? <Eye size={16} /> : <EyeOff size={16} />}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
