import React from 'react';
import { Accordion } from '@/components/ui/accordion';
import { FAQItem } from '@/components/support/FAQItem';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';

export const FAQSection: React.FC = () => {
  const faqs = [
    {
      id: 'faq-1',
      question: 'How do I make a bill payment?',
      answer: 'To make a bill payment, navigate to the "Bill Payments" section from your dashboard. Select the biller category (e.g., Electricity, Cable TV, Internet), choose your provider, enter the required details, and proceed to payment. You can pay using your account balance or other payment methods.',
    },
    {
      id: 'faq-2',
      question: 'What types of transfers can I make with Billze?',
      answer: 'Billze supports various transfer types including local bank transfers to any Nigerian bank, intra-bank transfers between Billze users, and international remittances to select countries. All transfers are processed securely and most local transfers reflect instantly.',
    },
    {
      id: 'faq-3',
      question: 'How do I apply for a loan?',
      answer: 'To apply for a loan, go to the "Loans" section on your dashboard. Select the loan type you\'re interested in, enter the amount needed and preferred duration. Our system will instantly assess your eligibility based on your transaction history and credit score. If approved, funds will be disbursed to your account.',
    },
    {
      id: 'faq-4',
      question: 'What savings plans are available?',
      answer: 'Billze offers various savings options including Fixed Savings with competitive interest rates, Goal-based Savings for specific targets, Group Savings for collective saving with friends or family, and Flexible Savings that allow withdrawals anytime. Each plan has different features to suit your financial goals.',
    },
    {
      id: 'faq-5',
      question: 'How secure is my data on Billze?',
      answer: 'We take security seriously. Billze employs bank-grade encryption for all data, multi-factor authentication for account access, and regular security audits. Your financial information is never stored on your device, and all transactions require authorization through secure channels.',
    },
  ];

  return (
    <Card className="w-full shadow-sm">
      <CardHeader className="flex flex-row items-center gap-2">
        <Icon icon="circle-question" className="text-blue-500 h-5 w-5" />
        <CardTitle className="text-xl">Frequently Asked Questions</CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq) => (
            <FAQItem 
              key={faq.id}
              value={faq.id}
              question={faq.question}
              answer={faq.answer}
            />
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
};
