import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';

interface SupportChannelProps {
  icon: string;
  title: string;
  description: string;
  contactInfo: string;
  availability: string;
}

const SupportChannel: React.FC<SupportChannelProps> = ({
  icon,
  title,
  description,
  contactInfo,
  availability
}) => {
  return (
    <div className="flex flex-col p-4 border rounded-lg bg-white dark:bg-gray-800 hover:border-blue-500 transition-all duration-200">
      <div className="flex items-center mb-3">
        <div className="p-2 rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300 mr-3">
          <Icon icon={icon} className="h-5 w-5" />
        </div>
        <h3 className="font-medium">{title}</h3>
      </div>
      <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">{description}</p>
      <div className="mt-auto">
        <p className="text-sm font-medium">{contactInfo}</p>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{availability}</p>
      </div>
    </div>
  );
};

export const SupportChannels: React.FC = () => {
  const channels = [
    {
      icon: 'phone',
      title: 'Phone Support',
      description: 'Speak directly with our customer service representatives for immediate assistance.',
      contactInfo: '+234 (0) 123-456-7890',
      availability: 'Available 8am - 8pm (Mon-Fri), 9am - 5pm (Sat)'
    },
    {
      icon: 'envelope',
      title: 'Email Support',
      description: 'Send us an email for non-urgent inquiries or detailed questions.',
      contactInfo: 'support@billze.com',
      availability: 'Responses within 24 hours'
    },
    {
      icon: 'comment-dots',
      title: 'Live Chat',
      description: 'Chat with our support team in real-time through our in-app messaging system.',
      contactInfo: 'Click the chat icon in the bottom right',
      availability: 'Available 24/7'
    },
    {
      icon: 'whatsapp',
      title: 'WhatsApp Support',
      description: 'Connect with us on WhatsApp for convenient mobile support.',
      contactInfo: '+234 (0) 987-654-3210',
      availability: 'Available 9am - 6pm (Mon-Sat)'
    }
  ];

  return (
    <Card className="w-full shadow-sm">
      <CardHeader className="flex flex-row items-center gap-2">
        <Icon icon="headphones" className="text-blue-500 h-5 w-5" />
        <CardTitle className="text-xl">Support Channels</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {channels.map((channel, index) => (
            <SupportChannel
              key={index}
              icon={channel.icon}
              title={channel.title}
              description={channel.description}
              contactInfo={channel.contactInfo}
              availability={channel.availability}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
