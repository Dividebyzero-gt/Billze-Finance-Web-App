import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';

interface ResourceItemProps {
  icon: string;
  title: string;
  description: string;
  link: string;
}

const ResourceItem: React.FC<ResourceItemProps> = ({ icon, title, description, link }) => {
  return (
    <a 
      href={link} 
      className="flex items-start p-4 border rounded-lg hover:border-blue-500 hover:shadow-sm transition-all duration-200 bg-white dark:bg-gray-800"
      target="_blank" 
      rel="noopener noreferrer"
    >
      <div className="p-2 rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300 mr-3">
        <Icon icon={icon} className="h-5 w-5" />
      </div>
      <div>
        <h3 className="font-medium mb-1">{title}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300">{description}</p>
      </div>
    </a>
  );
};

export const SupportResources: React.FC = () => {
  const resources = [
    {
      icon: 'book-open',
      title: 'User Guide',
      description: 'Comprehensive guide on how to use all Billze features',
      link: '#user-guide'
    },
    {
      icon: 'video',
      title: 'Video Tutorials',
      description: 'Step-by-step video guides for common tasks',
      link: '#video-tutorials'
    },
    {
      icon: 'newspaper',
      title: 'Blog & Updates',
      description: 'Latest news, tips, and feature updates',
      link: '#blog'
    },
    {
      icon: 'shield-alt',
      title: 'Security Guide',
      description: 'Best practices for keeping your account secure',
      link: '#security'
    },
    {
      icon: 'money-bill-wave',
      title: 'Financial Tips',
      description: 'Advice on managing your finances effectively',
      link: '#financial-tips'
    },
    {
      icon: 'question-circle',
      title: 'Knowledge Base',
      description: 'Searchable database of common questions and answers',
      link: '#knowledge-base'
    }
  ];

  return (
    <Card className="w-full shadow-sm">
      <CardHeader className="flex flex-row items-center gap-2">
        <Icon icon="book" className="text-blue-500 h-5 w-5" />
        <CardTitle className="text-xl">Helpful Resources</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resources.map((resource, index) => (
            <ResourceItem
              key={index}
              icon={resource.icon}
              title={resource.title}
              description={resource.description}
              link={resource.link}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
