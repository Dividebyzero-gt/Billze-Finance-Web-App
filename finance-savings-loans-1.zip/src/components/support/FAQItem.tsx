import React from 'react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';

interface FAQItemProps {
  question: string;
  answer: string;
  value: string;
}

export const FAQItem: React.FC<FAQItemProps> = ({ question, answer, value }) => {
  return (
    <AccordionItem value={value}>
      <AccordionTrigger className="text-left">{question}</AccordionTrigger>
      <AccordionContent>
        <p className="text-gray-600 dark:text-gray-300">{answer}</p>
      </AccordionContent>
    </AccordionItem>
  );
};
