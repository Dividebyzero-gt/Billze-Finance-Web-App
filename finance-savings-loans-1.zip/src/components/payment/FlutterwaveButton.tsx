import React from 'react';
import { Button } from '@/components/ui/button';
import { generateTransactionReference } from '@/lib/flutterwave';
import { useNavigate } from 'react-router-dom';

interface PaymentButtonProps {
  amount: number;
  customerEmail: string;
  customerName: string;
  customerPhone?: string;
  paymentDescription?: string;
  className?: string;
  onSuccess?: (response: any) => void;
  onClose?: () => void;
  disabled?: boolean;
  children?: React.ReactNode;
}

// This is a simplified version that replaces the Flutterwave integration
export function FlutterwaveButton({
  amount,
  customerEmail,
  customerName,
  className = '',
  onSuccess,
  onClose,
  disabled = false,
  children,
}: PaymentButtonProps) {
  const navigate = useNavigate();
  const txRef = generateTransactionReference();
  
  const handlePayment = () => {
    // Simulate payment process
    setTimeout(() => {
      if (onSuccess) {
        onSuccess({
          transaction_id: Math.random().toString(36).substring(2, 15),
          tx_ref: txRef,
          amount: amount,
          status: 'successful'
        });
      }
      
      // Redirect to success page
      navigate(`/payment-callback?status=successful&tx_ref=${txRef}`);
    }, 1000);
  };

  return (
    <Button
      onClick={handlePayment}
      disabled={disabled}
      className={className}
    >
      {children || 'Pay Now'}
    </Button>
  );
}
