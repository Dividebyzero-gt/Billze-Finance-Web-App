import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface PaymentStatus {
  status: 'success' | 'failed' | 'pending' | 'verifying';
  message: string;
  data?: any;
}

export function PaymentCallback() {
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>({
    status: 'verifying',
    message: 'Verifying your payment...',
  });
  
  const location = useLocation();
  const navigate = useNavigate();
  
  useEffect(() => {
    const verifyTransaction = async () => {
      try {
        // Parse URL parameters
        const params = new URLSearchParams(location.search);
        const status = params.get('status');
        const tx_ref = params.get('tx_ref');
        
        if (!tx_ref) {
          setPaymentStatus({
            status: 'failed',
            message: 'Invalid payment response. Missing transaction reference.',
          });
          return;
        }
        
        // Simulate verification delay
        setTimeout(() => {
          if (status === 'successful') {
            setPaymentStatus({
              status: 'success',
              message: 'Payment completed successfully!',
              data: {
                data: {
                  tx_ref: tx_ref,
                  amount: 5000,
                  currency: 'NGN',
                  status: 'successful'
                }
              },
            });
          } else {
            setPaymentStatus({
              status: 'failed',
              message: 'Payment verification failed. Please contact support.',
              data: { tx_ref: tx_ref },
            });
          }
        }, 2000);
      } catch (error) {
        console.error('Error verifying payment:', error);
        setPaymentStatus({
          status: 'failed',
          message: 'An error occurred while verifying your payment.',
        });
      }
    };
    
    verifyTransaction();
  }, [location]);
  
  const handleReturn = () => {
    navigate('/dashboard');
  };
  
  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>
            {paymentStatus.status === 'verifying' && 'Verifying Payment'}
            {paymentStatus.status === 'success' && 'Payment Successful'}
            {paymentStatus.status === 'failed' && 'Payment Failed'}
            {paymentStatus.status === 'pending' && 'Payment Pending'}
          </CardTitle>
          <CardDescription>
            {paymentStatus.message}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {paymentStatus.status === 'verifying' && (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          )}
          
          {paymentStatus.status === 'success' && (
            <div className="text-center py-4">
              <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
                <svg className="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-sm text-gray-600">
                Transaction Reference: {paymentStatus.data?.data?.tx_ref || 'N/A'}
              </p>
              {paymentStatus.data?.data?.amount && (
                <p className="text-sm text-gray-600 mt-1">
                  Amount: {paymentStatus.data.data.currency} {paymentStatus.data.data.amount}
                </p>
              )}
            </div>
          )}
          
          {paymentStatus.status === 'failed' && (
            <div className="text-center py-4">
              <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4">
                <svg className="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <p className="text-sm text-gray-600">
                Please try again or contact customer support if the issue persists.
              </p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button onClick={handleReturn}>
            Return to Dashboard
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
