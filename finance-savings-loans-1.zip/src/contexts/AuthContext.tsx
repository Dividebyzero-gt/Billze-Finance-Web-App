import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@/types';
import { supabase } from '@/lib/supabase';
import { loginUser } from '@/lib/supabase-auth';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, phone: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Check if user is logged in with Supabase
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session && session.user) {
        const userData: User = {
          id: session.user.id,
          name: session.user.user_metadata.name || '',
          email: session.user.email || '',
          phone: session.user.user_metadata.phone || '',
          accountNumber: session.user.user_metadata.account_number || '',
          accountBalance: session.user.user_metadata.account_balance || 0,
        };
        setUser(userData);
      } else {
        setUser(null);
      }
      setIsLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // For demo purposes, if email is igwilohnnaa@gmail.com and password is General123@
      // we'll allow login without actually checking with Supabase
      if (email === 'igwilohnnaa@gmail.com' && password === 'General123@') {
        const mockUser: User = {
          id: '123456',
          name: 'John Igwilo',
          email: 'igwilohnnaa@gmail.com',
          phone: '+2348012345678',
          accountNumber: '2023456789',
          accountBalance: 5000,
        };
        setUser(mockUser);
        return;
      }
      
      // Normal login flow with Supabase
      const { user: authUser } = await loginUser(email, password);
      if (authUser) {
        const userData: User = {
          id: authUser.id,
          name: authUser.user_metadata.name || '',
          email: authUser.email || '',
          phone: authUser.user_metadata.phone || '',
          accountNumber: authUser.user_metadata.account_number || '',
          accountBalance: authUser.user_metadata.account_balance || 0,
        };
        setUser(userData);
      }
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string, phone: string) => {
    setIsLoading(true);
    try {
      const { data: { user: authUser } } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            phone,
            account_number: Math.floor(1000000000 + Math.random() * 9000000000).toString(),
            account_balance: 0,
          }
        }
      });
      
      if (authUser) {
        const userData: User = {
          id: authUser.id,
          name,
          email,
          phone,
          accountNumber: authUser.user_metadata.account_number,
          accountBalance: 0,
        };
        setUser(userData);
      }
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
