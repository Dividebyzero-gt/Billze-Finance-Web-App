import React, { createContext, useContext, useState, useEffect } from 'react';
import { Account, AccountFormData } from '@/types/account';
import { mockAccounts, generateAccountNumber } from '@/lib/mock-accounts';

interface AccountContextType {
  accounts: Account[];
  loading: boolean;
  error: string | null;
  addAccount: (accountData: AccountFormData) => Promise<void>;
  deleteAccount: (accountId: string) => Promise<void>;
  toggleMaskAccount: (accountId: string) => void;
  setDefaultAccount: (accountId: string) => void;
}

const AccountContext = createContext<AccountContextType | undefined>(undefined);

export const AccountProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load accounts on initial render
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setAccounts(mockAccounts);
      setLoading(false);
    }, 500);
  }, []);

  const addAccount = async (accountData: AccountFormData): Promise<void> => {
    try {
      setLoading(true);
      // Simulate API call
      const newAccount: Account = {
        id: `acc-${Date.now()}`,
        userId: 'user-1', // In a real app, get this from auth context
        accountNumber: generateAccountNumber(),
        balance: 0,
        isDefault: accounts.length === 0, // First account is default
        isMasked: false,
        createdAt: new Date().toISOString(),
        ...accountData
      };
      
      // Add the new account
      setAccounts(prev => [...prev, newAccount]);
      setLoading(false);
    } catch (err) {
      setError('Failed to create account');
      setLoading(false);
    }
  };

  const deleteAccount = async (accountId: string): Promise<void> => {
    try {
      setLoading(true);
      // Simulate API call
      const updatedAccounts = accounts.filter(acc => acc.id !== accountId);
      
      // If we deleted the default account, set a new default
      if (accounts.find(acc => acc.id === accountId)?.isDefault && updatedAccounts.length > 0) {
        updatedAccounts[0].isDefault = true;
      }
      
      setAccounts(updatedAccounts);
      setLoading(false);
    } catch (err) {
      setError('Failed to delete account');
      setLoading(false);
    }
  };

  const toggleMaskAccount = (accountId: string): void => {
    setAccounts(prev => 
      prev.map(acc => 
        acc.id === accountId 
          ? { ...acc, isMasked: !acc.isMasked } 
          : acc
      )
    );
  };

  const setDefaultAccount = (accountId: string): void => {
    setAccounts(prev => 
      prev.map(acc => ({
        ...acc,
        isDefault: acc.id === accountId
      }))
    );
  };

  return (
    <AccountContext.Provider 
      value={{
        accounts,
        loading,
        error,
        addAccount,
        deleteAccount,
        toggleMaskAccount,
        setDefaultAccount
      }}
    >
      {children}
    </AccountContext.Provider>
  );
};

export const useAccounts = (): AccountContextType => {
  const context = useContext(AccountContext);
  if (context === undefined) {
    throw new Error('useAccounts must be used within an AccountProvider');
  }
  return context;
};
