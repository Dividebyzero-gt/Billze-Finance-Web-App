import React, { createContext, useContext } from 'react';

interface AppContextType {
  // Add any global app state properties here if needed
  // The sidebar open/close state is no longer needed as we're using a fixed sidebar
}

const defaultAppContext: AppContextType = {};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Add any global app state here if needed

  return (
    <AppContext.Provider
      value={{}}
    >
      {children}
    </AppContext.Provider>
  );
};
