import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { UserSettings, defaultSettings, getUserSettings, updateUserSettings } from '@/lib/settings';
import { useTheme } from '@/components/theme-provider';

interface SettingsContextType {
  settings: UserSettings;
  isLoading: boolean;
  updateSettings: (newSettings: Partial<UserSettings>) => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};

interface SettingsProviderProps {
  children: ReactNode;
}

export const SettingsProvider: React.FC<SettingsProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const { setTheme } = useTheme();
  const [settings, setSettings] = useState<UserSettings>(defaultSettings);
  const [isLoading, setIsLoading] = useState<boolean>(false); // Changed to false initially

  // Load user settings when user changes
  useEffect(() => {
    const loadSettings = async () => {
      if (user) {
        setIsLoading(true);
        try {
          const userSettings = await getUserSettings(user.id);
          setSettings(userSettings);
          
          // Sync theme with ThemeProvider
          if (userSettings.theme) {
            setTheme(userSettings.theme);
          }
        } catch (error) {
          console.error('Failed to load settings:', error);
        } finally {
          setIsLoading(false);
        }
      } else {
        // Reset to defaults if no user
        setSettings(defaultSettings);
        setIsLoading(false);
      }
    };

    loadSettings();
  }, [user, setTheme]);

  // Update settings in the database and local state
  const updateSettings = async (newSettings: Partial<UserSettings>) => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      // Update theme immediately for better UX
      if (newSettings.theme) {
        setTheme(newSettings.theme);
      }
      
      // Update local state immediately for better UX
      const updatedSettings = { ...settings, ...newSettings };
      setSettings(updatedSettings);
      
      // Update in database (now just returns the merged settings)
      const savedSettings = await updateUserSettings(user.id, newSettings);
      setSettings(savedSettings);
    } catch (error) {
      console.error('Failed to update settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    settings,
    isLoading,
    updateSettings,
  };

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
};
