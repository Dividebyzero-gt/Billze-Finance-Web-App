import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Globe, DollarSign, PoundSterling, Euro, Clock, Users } from 'lucide-react';

const Remittance: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">International Remittance</h1>
        <Button variant="outline" className="flex items-center gap-2">
          <Clock size={16} />
          <span>Transaction History</span>
        </Button>
      </div>
      
      <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-100">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex-shrink-0">
            <Globe className="h-16 w-16 text-blue-500" />
          </div>
          <div className="flex-grow">
            <h2 className="text-xl font-semibold mb-2">Send Money Worldwide</h2>
            <p className="text-gray-600 mb-4">
              Transfer money to friends and family around the globe with competitive exchange rates and low fees.
            </p>
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-full text-sm border border-blue-100">
                <DollarSign size={14} className="text-blue-500" />
                <span>USD</span>
              </div>
              <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-full text-sm border border-blue-100">
                <PoundSterling size={14} className="text-blue-500" />
                <span>GBP</span>
              </div>
              <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-full text-sm border border-blue-100">
                <Euro size={14} className="text-blue-500" />
                <span>EUR</span>
              </div>
              <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-full text-sm border border-blue-100">
                <span className="text-blue-500 font-bold">¥</span>
                <span>CNY</span>
              </div>
              <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-full text-sm border border-blue-100">
                <span className="text-blue-500 font-bold">C$</span>
                <span>CAD</span>
              </div>
              <span className="text-sm text-gray-500 self-center">+20 more</span>
            </div>
          </div>
        </div>
      </Card>
      
      <Tabs defaultValue="send">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="send">Send Money</TabsTrigger>
          <TabsTrigger value="receive">Receive Money</TabsTrigger>
        </TabsList>
        
        <TabsContent value="send" className="mt-4">
          <Card className="p-6">
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="from-account">From Account</Label>
                <Select defaultValue="savings">
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="savings">Savings Account - ₦59,807.37</SelectItem>
                    <SelectItem value="current">Current Account - ₦0.00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="country">Recipient Country</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="usa">United States</SelectItem>
                    <SelectItem value="uk">United Kingdom</SelectItem>
                    <SelectItem value="canada">Canada</SelectItem>
                    <SelectItem value="ghana">Ghana</SelectItem>
                    <SelectItem value="kenya">Kenya</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount to Send (₦)</Label>
                  <Input id="amount" type="number" placeholder="Enter amount in Naira" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="converted-amount">They Receive (USD)</Label>
                  <Input id="converted-amount" type="number" placeholder="0.00" disabled />
                </div>
              </div>
              
              <div className="p-3 bg-blue-50 rounded-md text-sm">
                <p className="font-medium text-blue-700">Exchange Rate: 1 USD = ₦750.00</p>
                <p className="text-gray-600">Fee: ₦2,000.00</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="recipient-name">Recipient's Full Name</Label>
                <Input id="recipient-name" placeholder="Enter recipient's name" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="recipient-email">Recipient's Email</Label>
                <Input id="recipient-email" type="email" placeholder="Enter recipient's email" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="transfer-reason">Reason for Transfer</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select reason" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="family">Family Support</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="medical">Medical Expenses</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button type="submit" className="w-full">Continue</Button>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="receive" className="mt-4">
          <Card className="p-6">
            <div className="text-center space-y-4">
              <div className="mx-auto bg-blue-100 rounded-full p-4 w-16 h-16 flex items-center justify-center">
                <Globe className="h-8 w-8 text-blue-600" />
              </div>
              <h2 className="text-xl font-semibold">Receive Money from Abroad</h2>
              <p className="text-gray-600">
                Share your account details with friends and family abroad to receive money directly into your account.
              </p>
              
              <div className="bg-gray-50 p-4 rounded-md text-left mt-4">
                <h3 className="font-medium mb-2">Your Account Details</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Account Name:</span>
                    <span className="font-medium">John Igwilo</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Account Number:</span>
                    <span className="font-medium">6113571689</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Bank:</span>
                    <span className="font-medium">Billze Bank</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Swift Code:</span>
                    <span className="font-medium">BLZENGLA</span>
                  </div>
                </div>
              </div>
              
              <Button className="mt-4">Copy Account Details</Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <Users className="h-8 w-8 text-blue-500" />
            <div>
              <h3 className="font-medium">International Beneficiaries</h3>
              <p className="text-sm text-gray-500">Manage your international recipients</p>
            </div>
          </div>
          <Button variant="outline" className="w-full mt-3">Manage Beneficiaries</Button>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <Clock className="h-8 w-8 text-blue-500" />
            <div>
              <h3 className="font-medium">Transaction History</h3>
              <p className="text-sm text-gray-500">View all your remittance transactions</p>
            </div>
          </div>
          <Button variant="outline" className="w-full mt-3">View History</Button>
        </Card>
      </div>
    </div>
  );
};

export default Remittance;
