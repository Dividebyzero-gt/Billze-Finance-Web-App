import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, Calculator, Calendar, AlertCircle, CheckCircle2, Clock } from 'lucide-react';

const Loans: React.FC = () => {
  const [loanAmount, setLoanAmount] = React.useState<number>(50000);
  const [loanTenure, setLoanTenure] = React.useState<number>(6);
  const [monthlyPayment, setMonthlyPayment] = React.useState<number>(8916.67);
  const [totalPayment, setTotalPayment] = React.useState<number>(53500);
  
  // Simple loan calculator
  const calculateLoan = (amount: number, months: number) => {
    const interestRate = 0.07; // 7% interest rate
    const totalAmount = amount * (1 + interestRate);
    const monthly = totalAmount / months;
    
    setMonthlyPayment(monthly);
    setTotalPayment(totalAmount);
  };
  
  React.useEffect(() => {
    calculateLoan(loanAmount, loanTenure);
  }, [loanAmount, loanTenure]);
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value)) {
      setLoanAmount(value);
    }
  };
  
  const handleTenureChange = (value: string) => {
    setLoanTenure(parseInt(value));
  };
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Loans & Credit</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 border-blue-200">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-blue-100 p-2 rounded-full">
              <CreditCard className="h-6 w-6 text-blue-600" />
            </div>
            <h2 className="text-xl font-semibold">Loan Eligibility</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Credit Score</span>
              <div className="flex items-center">
                <span className="font-medium mr-2">720</span>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full">Good</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Maximum Eligible Amount</span>
              <span className="font-medium">₦500,000.00</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Interest Rate</span>
              <span className="font-medium">7% p.a.</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Processing Fee</span>
              <span className="font-medium">1% of loan amount</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Repayment Period</span>
              <span className="font-medium">Up to 24 months</span>
            </div>
            
            <div className="bg-blue-50 p-3 rounded-md text-sm text-blue-700 flex items-start space-x-2">
              <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
              <p>Your eligibility is based on your account history, income, and credit score.</p>
            </div>
          </div>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-blue-100 p-2 rounded-full">
              <Calculator className="h-6 w-6 text-blue-600" />
            </div>
            <h2 className="text-xl font-semibold">Loan Calculator</h2>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="loan-amount">Loan Amount</Label>
              <Input 
                id="loan-amount" 
                type="number" 
                value={loanAmount} 
                onChange={handleAmountChange}
                min={10000}
                max={500000}
                step={10000}
              />
              <div className="pt-2">
                <input 
                  type="range" 
                  min={10000} 
                  max={500000} 
                  step={10000} 
                  value={loanAmount}
                  onChange={handleAmountChange}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>₦10,000</span>
                  <span>₦500,000</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="tenure">Loan Tenure (Months)</Label>
              <Select value={loanTenure.toString()} onValueChange={handleTenureChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select tenure" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 Months</SelectItem>
                  <SelectItem value="6">6 Months</SelectItem>
                  <SelectItem value="12">12 Months</SelectItem>
                  <SelectItem value="18">18 Months</SelectItem>
                  <SelectItem value="24">24 Months</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-md space-y-3 mt-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Monthly Payment</span>
                <span className="font-medium">₦{monthlyPayment.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total Payment</span>
                <span className="font-medium">₦{totalPayment.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total Interest</span>
                <span className="font-medium">₦{(totalPayment - loanAmount).toFixed(2)}</span>
              </div>
            </div>
            
            <Button className="w-full mt-2">Apply for Loan</Button>
          </div>
        </Card>
      </div>
      
      <Tabs defaultValue="personal">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="personal">Personal Loan</TabsTrigger>
          <TabsTrigger value="business">Business Loan</TabsTrigger>
          <TabsTrigger value="active">Active Loans</TabsTrigger>
        </TabsList>
        
        <TabsContent value="personal" className="mt-4">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Apply for Personal Loan</h3>
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="loan-purpose">Loan Purpose</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select purpose" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="medical">Medical Expenses</SelectItem>
                    <SelectItem value="home">Home Improvement</SelectItem>
                    <SelectItem value="debt">Debt Consolidation</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="loan-amount">Loan Amount</Label>
                <Input id="loan-amount" type="number" placeholder="Enter amount" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="tenure">Loan Tenure</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select tenure" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 Months</SelectItem>
                    <SelectItem value="6">6 Months</SelectItem>
                    <SelectItem value="12">12 Months</SelectItem>
                    <SelectItem value="18">18 Months</SelectItem>
                    <SelectItem value="24">24 Months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button type="submit" className="w-full">Submit Application</Button>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="business" className="mt-4">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Apply for Business Loan</h3>
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="business-name">Business Name</Label>
                <Input id="business-name" placeholder="Enter business name" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="business-type">Business Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select business type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sole-proprietorship">Sole Proprietorship</SelectItem>
                    <SelectItem value="partnership">Partnership</SelectItem>
                    <SelectItem value="llc">Limited Liability Company</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="loan-amount">Loan Amount</Label>
                <Input id="loan-amount" type="number" placeholder="Enter amount" />
              </div>
              
              <Button type="submit" className="w-full">Submit Application</Button>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="active" className="mt-4">
          <Card className="p-6">
            <div className="text-center py-8">
              <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-3" />
              <h3 className="text-lg font-medium">No Active Loans</h3>
              <p className="text-gray-500 mb-4">You don't have any active loans at the moment.</p>
              <Button>Apply for a Loan</Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Loans;