import React from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { FAQSection } from '@/components/support/FAQSection';
import { ContactSupport } from '@/components/support/ContactSupport';
import { SupportChannels } from '@/components/support/SupportChannels';
import { SupportResources } from '@/components/support/SupportResources';

export function Support() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <SupportChannels />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ContactSupport />
          <FAQSection />
        </div>
        
        <SupportResources />
      </div>
    </DashboardLayout>
  );
}

export default Support;
