import React, { useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useSettings } from '@/contexts/SettingsContext';
import AppearanceSettings from '@/components/settings/AppearanceSettings';
import LanguageSettings from '@/components/settings/LanguageSettings';
import PrivacySettings from '@/components/settings/PrivacySettings';
import NotificationSettings from '@/components/settings/NotificationSettings';

const Settings: React.FC = () => {
  const { user, logout } = useAuth();
  const { settings, isLoading } = useSettings();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <AppearanceSettings />
        <LanguageSettings />
        <PrivacySettings />
        <NotificationSettings />
      </div>
      
      <Card className="p-6 border-red-100">
        <h2 className="text-lg font-medium mb-4">Account Actions</h2>
        <div className="space-y-4">
          <Button variant="destructive" className="w-full" onClick={logout}>
            <LogOut className="h-4 w-4 mr-2" />
            Log Out of All Devices
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default Settings;
