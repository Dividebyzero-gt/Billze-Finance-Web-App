import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowRight, Users, Building, Globe } from 'lucide-react';

const Transfers: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Money Transfers</h1>
      
      <Tabs defaultValue="own-account">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="own-account">Own Account</TabsTrigger>
          <TabsTrigger value="other-banks">Other Banks</TabsTrigger>
          <TabsTrigger value="international">International</TabsTrigger>
        </TabsList>
        
        <TabsContent value="own-account" className="space-y-4 mt-4">
          <Card className="p-6">
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="from-account">From Account</Label>
                <Select defaultValue="savings">
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="savings">Savings Account - ₦59,807.37</SelectItem>
                    <SelectItem value="current">Current Account - ₦0.00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="to-account">To Account</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="current">Current Account - ₦0.00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input id="amount" type="number" placeholder="Enter amount" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Input id="description" placeholder="Enter description" />
              </div>
              
              <Button type="submit" className="w-full">Transfer <ArrowRight size={16} className="ml-2" /></Button>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="other-banks" className="space-y-4 mt-4">
          <Card className="p-6">
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="from-account">From Account</Label>
                <Select defaultValue="savings">
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="savings">Savings Account - ₦59,807.37</SelectItem>
                    <SelectItem value="current">Current Account - ₦0.00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bank">Recipient Bank</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select bank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gtb">GTBank</SelectItem>
                    <SelectItem value="first">First Bank</SelectItem>
                    <SelectItem value="zenith">Zenith Bank</SelectItem>
                    <SelectItem value="uba">UBA</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="account-number">Account Number</Label>
                <Input id="account-number" placeholder="Enter 10-digit account number" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input id="amount" type="number" placeholder="Enter amount" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Input id="description" placeholder="Enter description" />
              </div>
              
              <Button type="submit" className="w-full">Transfer <ArrowRight size={16} className="ml-2" /></Button>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="international" className="space-y-4 mt-4">
          <Card className="p-6">
            <div className="text-center p-4">
              <Globe className="mx-auto h-12 w-12 text-blue-500 mb-2" />
              <h3 className="text-lg font-medium">International Transfers</h3>
              <p className="text-gray-500 mb-4">Send money to friends and family worldwide</p>
              <Button>Set Up International Transfer</Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <Users className="h-8 w-8 text-blue-500" />
            <div>
              <h3 className="font-medium">Manage Beneficiaries</h3>
              <p className="text-sm text-gray-500">Save and manage your frequent recipients</p>
            </div>
          </div>
          <Button variant="outline" className="w-full mt-3">View Beneficiaries</Button>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <Building className="h-8 w-8 text-blue-500" />
            <div>
              <h3 className="font-medium">Standing Orders</h3>
              <p className="text-sm text-gray-500">Set up recurring transfers</p>
            </div>
          </div>
          <Button variant="outline" className="w-full mt-3">Manage Standing Orders</Button>
        </Card>
      </div>
    </div>
  );
};

export default Transfers;
