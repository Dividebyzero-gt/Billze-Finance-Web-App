import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Phone, Tv, Droplet, Home, Receipt, Clock } from 'lucide-react';

interface BillCategoryProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}

const BillCategory: React.FC<BillCategoryProps> = ({ icon, title, description, onClick }) => {
  return (
    <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow" onClick={onClick}>
      <div className="flex items-center space-x-3">
        <div className="bg-blue-100 p-2 rounded-full">
          {icon}
        </div>
        <div>
          <h3 className="font-medium">{title}</h3>
          <p className="text-sm text-gray-500">{description}</p>
        </div>
      </div>
    </Card>
  );
};

const Bills: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = React.useState<string | null>(null);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Bill Payments</h1>
      
      {!selectedCategory ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <BillCategory 
            icon={<Zap className="h-5 w-5 text-blue-600" />}
            title="Electricity"
            description="Pay your electricity bills"
            onClick={() => handleCategorySelect('electricity')}
          />
          <BillCategory 
            icon={<Phone className="h-5 w-5 text-blue-600" />}
            title="Airtime & Data"
            description="Recharge phone and buy data"
            onClick={() => handleCategorySelect('airtime')}
          />
          <BillCategory 
            icon={<Tv className="h-5 w-5 text-blue-600" />}
            title="TV Subscription"
            description="DStv, GOtv, StarTimes"
            onClick={() => handleCategorySelect('tv')}
          />
          <BillCategory 
            icon={<Droplet className="h-5 w-5 text-blue-600" />}
            title="Water"
            description="Pay water utility bills"
            onClick={() => handleCategorySelect('water')}
          />
          <BillCategory 
            icon={<Home className="h-5 w-5 text-blue-600" />}
            title="Internet"
            description="Pay for internet services"
            onClick={() => handleCategorySelect('internet')}
          />
          <BillCategory 
            icon={<Receipt className="h-5 w-5 text-blue-600" />}
            title="Tax Payments"
            description="Pay government taxes"
            onClick={() => handleCategorySelect('tax')}
          />
        </div>
      ) : (
        <div>
          <Button variant="outline" className="mb-4" onClick={() => setSelectedCategory(null)}>
            <span className="mr-2">←</span> Back to Categories
          </Button>
          
          {selectedCategory === 'electricity' && (
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Electricity Bill Payment</h2>
              <form className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="provider">Select Provider</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select provider" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ekedc">Eko Electricity Distribution Company</SelectItem>
                      <SelectItem value="ikedc">Ikeja Electricity Distribution Company</SelectItem>
                      <SelectItem value="aedc">Abuja Electricity Distribution Company</SelectItem>
                      <SelectItem value="phedc">Port Harcourt Electricity Distribution Company</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="meter-type">Meter Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select meter type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="prepaid">Prepaid</SelectItem>
                      <SelectItem value="postpaid">Postpaid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="meter-number">Meter Number</Label>
                  <Input id="meter-number" placeholder="Enter meter number" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount</Label>
                  <Input id="amount" type="number" placeholder="Enter amount" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" placeholder="Enter phone number" />
                </div>
                
                <Button type="submit" className="w-full">Proceed to Payment</Button>
              </form>
            </Card>
          )}
          
          {selectedCategory === 'airtime' && (
            <Tabs defaultValue="airtime">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="airtime">Airtime</TabsTrigger>
                <TabsTrigger value="data">Data Bundle</TabsTrigger>
              </TabsList>
              
              <TabsContent value="airtime" className="mt-4">
                <Card className="p-6">
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="network">Select Network</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select network" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mtn">MTN</SelectItem>
                          <SelectItem value="airtel">Airtel</SelectItem>
                          <SelectItem value="glo">Glo</SelectItem>
                          <SelectItem value="9mobile">9Mobile</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" placeholder="Enter phone number" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount</Label>
                      <Input id="amount" type="number" placeholder="Enter amount" />
                    </div>
                    
                    <Button type="submit" className="w-full">Buy Airtime</Button>
                  </form>
                </Card>
              </TabsContent>
              
              <TabsContent value="data" className="mt-4">
                <Card className="p-6">
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="network">Select Network</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select network" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mtn">MTN</SelectItem>
                          <SelectItem value="airtel">Airtel</SelectItem>
                          <SelectItem value="glo">Glo</SelectItem>
                          <SelectItem value="9mobile">9Mobile</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" placeholder="Enter phone number" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="data-plan">Data Plan</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select data plan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1gb">1GB - ₦1,000 (30 days)</SelectItem>
                          <SelectItem value="2gb">2GB - ₦1,200 (30 days)</SelectItem>
                          <SelectItem value="5gb">5GB - ₦2,500 (30 days)</SelectItem>
                          <SelectItem value="10gb">10GB - ₦5,000 (30 days)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <Button type="submit" className="w-full">Buy Data</Button>
                  </form>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </div>
      )}
      
      <Card className="p-4 mt-6">
        <div className="flex items-center space-x-3">
          <Clock className="h-5 w-5 text-blue-600" />
          <div>
            <h3 className="font-medium">Recent Bill Payments</h3>
            <p className="text-sm text-gray-500">View your payment history</p>
          </div>
        </div>
        <Button variant="outline" className="w-full mt-3">View History</Button>
      </Card>
    </div>
  );
};

export default Bills;
