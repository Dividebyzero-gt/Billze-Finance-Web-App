import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Shield, Bell, Key, FileText } from 'lucide-react';

const Profile: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">My Profile</h1>
      
      <div className="flex flex-col md:flex-row gap-6">
        <Card className="p-6 md:w-1/3">
          <div className="flex flex-col items-center text-center">
            <Avatar className="h-24 w-24 mb-4">
              <AvatarImage src="/placeholder.svg" alt="Profile" />
              <AvatarFallback>JI</AvatarFallback>
            </Avatar>
            <h2 className="text-xl font-semibold">John Igwilo</h2>
            <p className="text-gray-500 mb-4">igwilohnnaa@gmail.com</p>
            <Button variant="outline" className="w-full">Change Profile Picture</Button>
          </div>
          
          <div className="mt-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Account Number</span>
              <span className="font-medium">6113571689</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Account Type</span>
              <span className="font-medium">Savings</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">BVN</span>
              <span className="font-medium">221******45</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Joined</span>
              <span className="font-medium">May 12, 2024</span>
            </div>
          </div>
        </Card>
        
        <div className="md:w-2/3">
          <Tabs defaultValue="personal">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="personal">
                <User className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Personal</span>
              </TabsTrigger>
              <TabsTrigger value="security">
                <Shield className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Security</span>
              </TabsTrigger>
              <TabsTrigger value="notifications">
                <Bell className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Notifications</span>
              </TabsTrigger>
              <TabsTrigger value="documents">
                <FileText className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Documents</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="personal" className="mt-4">
              <Card className="p-6">
                <h3 className="text-lg font-medium mb-4">Personal Information</h3>
                <form className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="first-name">First Name</Label>
                      <Input id="first-name" defaultValue="John" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name">Last Name</Label>
                      <Input id="last-name" defaultValue="Igwilo" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" defaultValue="igwilohnnaa@gmail.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" defaultValue="+234 800 123 4567" />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <Input id="address" defaultValue="123 Main Street, Lagos" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input id="city" defaultValue="Lagos" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">State</Label>
                      <Input id="state" defaultValue="Lagos State" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="zip">Postal Code</Label>
                      <Input id="zip" defaultValue="100001" />
                    </div>
                  </div>
                  
                  <Button type="submit">Save Changes</Button>
                </form>
              </Card>
            </TabsContent>
            
            <TabsContent value="security" className="mt-4">
              <Card className="p-6">
                <h3 className="text-lg font-medium mb-4">Security Settings</h3>
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">Change Password</h4>
                    <div className="space-y-2">
                      <Label htmlFor="current-password">Current Password</Label>
                      <Input id="current-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                    <Button>Update Password</Button>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <h4 className="font-medium mb-4">Two-Factor Authentication</h4>
                    <p className="text-gray-600 mb-4">Add an extra layer of security to your account</p>
                    <Button variant="outline">
                      <Shield className="h-4 w-4 mr-2" />
                      Enable Two-Factor Authentication
                    </Button>
                  </div>
                </div>
              </Card>
            </TabsContent>
            
            <TabsContent value="notifications" className="mt-4">
              <Card className="p-6">
                <h3 className="text-lg font-medium mb-4">Notification Preferences</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Transaction Alerts</h4>
                      <p className="text-sm text-gray-500">Receive notifications for all transactions</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="transaction-email" className="rounded text-blue-600" defaultChecked />
                      <Label htmlFor="transaction-email" className="text-sm">Email</Label>
                      
                      <input type="checkbox" id="transaction-sms" className="ml-4 rounded text-blue-600" defaultChecked />
                      <Label htmlFor="transaction-sms" className="text-sm">SMS</Label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Security Alerts</h4>
                      <p className="text-sm text-gray-500">Receive alerts for security-related activities</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="security-email" className="rounded text-blue-600" defaultChecked />
                      <Label htmlFor="security-email" className="text-sm">Email</Label>
                      
                      <input type="checkbox" id="security-sms" className="ml-4 rounded text-blue-600" defaultChecked />
                      <Label htmlFor="security-sms" className="text-sm">SMS</Label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Promotional Messages</h4>
                      <p className="text-sm text-gray-500">Receive updates about new features and offers</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="promo-email" className="rounded text-blue-600" defaultChecked />
                      <Label htmlFor="promo-email" className="text-sm">Email</Label>
                      
                      <input type="checkbox" id="promo-sms" className="ml-4 rounded text-blue-600" />
                      <Label htmlFor="promo-sms" className="text-sm">SMS</Label>
                    </div>
                  </div>
                  
                  <Button className="mt-2">Save Preferences</Button>
                </div>
              </Card>
            </TabsContent>
            
            <TabsContent value="documents" className="mt-4">
              <Card className="p-6">
                <h3 className="text-lg font-medium mb-4">My Documents</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center space-x-3">
                      <FileText className="h-5 w-5 text-blue-600" />
                      <div>
                        <h4 className="font-medium">ID Card</h4>
                        <p className="text-sm text-gray-500">Uploaded on May 12, 2024</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">View</Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center space-x-3">
                      <FileText className="h-5 w-5 text-blue-600" />
                      <div>
                        <h4 className="font-medium">Proof of Address</h4>
                        <p className="text-sm text-gray-500">Uploaded on May 12, 2024</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">View</Button>
                  </div>
                  
                  <Button className="mt-2">
                    <FileText className="h-4 w-4 mr-2" />
                    Upload New Document
                  </Button>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Profile;