import React from 'react';
import { SEO } from '@/components/SEO';
import { HeroSection } from '@/components/home/HeroSection';
import { FeaturesSection } from '@/components/home/FeaturesSection';
import { TestimonialsSection } from '@/components/home/TestimonialsSection';
import { PricingSection } from '@/components/home/PricingSection';
import { AboutSection } from '@/components/home/AboutSection';
import { ContactSection } from '@/components/home/ContactSection';
import { CTASection } from '@/components/home/CTASection';
import { HomeLayout } from '@/components/layout/HomeLayout';

const HomePage: React.FC = () => {
  return (
    <HomeLayout>
      <SEO 
        title="Billze - Your Financial Life, Simplified" 
        description="Manage payments, savings, and loans all in one place with our secure and easy-to-use platform."
      />
      
      <div className="flex flex-col min-h-screen w-full">
        <HeroSection />
        <div id="features" className="w-full">
          <FeaturesSection />
        </div>
        <div id="testimonials" className="w-full">
          <TestimonialsSection />
        </div>
        <div id="pricing" className="w-full">
          <PricingSection />
        </div>
        <div id="about" className="w-full">
          <AboutSection />
        </div>
        <div id="contact" className="w-full">
          <ContactSection />
        </div>
        <CTASection />
      </div>
    </HomeLayout>
  );
};

export default HomePage;
