import React, { useState } from 'react';
import { useAccounts } from '@/contexts/AccountContext';
import { AccountForm } from '@/components/accounts/AccountForm';
import { AccountList } from '@/components/accounts/AccountList';
import { AccountSettings } from '@/components/accounts/AccountSettings';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { SEO } from '@/components/SEO';

export default function Accounts() {
  const { accounts, loading, addAccount, deleteAccount, toggleMaskAccount, setDefaultAccount } = useAccounts();
  const [maskAllAccounts, setMaskAllAccounts] = useState(false);
  const [hideBalances, setHideBalances] = useState(false);

  const handleToggleMaskAll = () => {
    setMaskAllAccounts(!maskAllAccounts);
    // Apply to all accounts
    accounts.forEach(account => {
      if (account.isMasked !== !maskAllAccounts) {
        toggleMaskAccount(account.id);
      }
    });
  };

  const handleToggleHideBalances = () => {
    setHideBalances(!hideBalances);
  };

  if (loading && accounts.length === 0) {
    return (
      <div className="container mx-auto py-6">
        <SEO title="Accounts" />
        <h1 className="text-2xl font-bold mb-6">Accounts</h1>
        <div className="space-y-4">
          <Skeleton className="h-[200px] w-full rounded-lg" />
          <Skeleton className="h-[200px] w-full rounded-lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <SEO title="Accounts" description="Manage all your bank accounts in one place" />
      
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">My Accounts</h1>
        <AccountForm onSubmit={addAccount} />
      </div>
      
      <Tabs defaultValue="accounts">
        <TabsList className="mb-4">
          <TabsTrigger value="accounts">Accounts</TabsTrigger>
          <TabsTrigger value="settings">Privacy Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="accounts">
          <Card>
            <CardHeader>
              <CardTitle>Your Accounts</CardTitle>
              <CardDescription>
                Manage all your bank accounts in one place.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AccountList 
                accounts={accounts}
                onToggleMask={toggleMaskAccount}
                onSetDefault={setDefaultAccount}
                onDelete={deleteAccount}
              />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <AccountSettings 
            maskAllAccounts={maskAllAccounts}
            onToggleMaskAll={handleToggleMaskAll}
            hideBalances={hideBalances}
            onToggleHideBalances={handleToggleHideBalances}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
