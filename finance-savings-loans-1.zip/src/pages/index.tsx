import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Index = () => {
  const navigate = useNavigate();

  return (
    <div>
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="flex flex-col items-center text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-blue-600 mb-6">Welcome to Billze</h1>
            <p className="text-xl md:text-2xl text-gray-700 max-w-3xl mb-10">
              Nigeria's most trusted fintech platform for bill payments, transfers, savings, and loans.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg"
                onClick={() => navigate('/register')}
              >
                Create Account
              </Button>
              <Button 
                variant="outline" 
                className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg"
                onClick={() => navigate('/login')}
              >
                Login
              </Button>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <section className="container mx-auto px-4 py-16 bg-white rounded-t-3xl shadow-sm">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: 'Bill Payments',
                description: 'Pay electricity, water, TV, and more instantly',
                icon: '💡'
              },
              {
                title: 'Money Transfers',
                description: 'Send money locally and internationally with ease',
                icon: '💸'
              },
              {
                title: 'Savings',
                description: 'Save towards your goals with competitive interest rates',
                icon: '💰'
              },
              {
                title: 'Loans',
                description: 'Access quick loans with low interest rates',
                icon: '🏦'
              }
            ].map((feature, index) => (
              <div key={index} className="bg-blue-50 p-6 rounded-xl text-center hover:shadow-md transition-shadow">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-blue-600 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Index;
