import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PiggyBank, TrendingUp, Calendar, Target, Plus, ArrowRight } from 'lucide-react';

interface SavingsPlanProps {
  title: string;
  amount: number;
  target: number;
  date: string;
  progress: number;
}

const SavingsPlan: React.FC<SavingsPlanProps> = ({ title, amount, target, date, progress }) => {
  return (
    <Card className="p-4">
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-medium">{title}</h3>
        <span className="text-sm bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
          Active
        </span>
      </div>
      <div className="flex justify-between text-sm text-gray-500 mb-1">
        <span>Current</span>
        <span>Target</span>
      </div>
      <div className="flex justify-between mb-2">
        <span className="font-medium">₦{amount.toLocaleString()}</span>
        <span className="font-medium">₦{target.toLocaleString()}</span>
      </div>
      <Progress value={progress} className="h-2 mb-3" />
      <div className="flex justify-between text-sm">
        <span className="text-gray-500">Target Date: {date}</span>
        <span className="text-blue-600 font-medium">{progress}%</span>
      </div>
      <div className="mt-3 flex space-x-2">
        <Button variant="outline" size="sm" className="flex-1">Top Up</Button>
        <Button size="sm" className="flex-1">Details</Button>
      </div>
    </Card>
  );
};

const Savings: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Savings & Investments</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4 bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
          <div className="flex items-center space-x-3 mb-2">
            <div className="bg-blue-500 p-2 rounded-full">
              <PiggyBank className="h-5 w-5 text-white" />
            </div>
            <h3 className="font-medium">Total Savings</h3>
          </div>
          <p className="text-2xl font-bold mb-1">₦125,000.00</p>
          <p className="text-sm text-gray-600">Across 3 savings plans</p>
        </Card>
        
        <Card className="p-4 bg-gradient-to-r from-green-50 to-green-100 border-green-200">
          <div className="flex items-center space-x-3 mb-2">
            <div className="bg-green-500 p-2 rounded-full">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
            <h3 className="font-medium">Interest Earned</h3>
          </div>
          <p className="text-2xl font-bold mb-1">₦3,750.00</p>
          <p className="text-sm text-gray-600">This month</p>
        </Card>
        
        <Card className="p-4 bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
          <div className="flex items-center space-x-3 mb-2">
            <div className="bg-purple-500 p-2 rounded-full">
              <Target className="h-5 w-5 text-white" />
            </div>
            <h3 className="font-medium">Goals Progress</h3>
          </div>
          <Progress value={45} className="h-2 mb-2" />
          <p className="text-sm text-gray-600">45% of target goals achieved</p>
        </Card>
      </div>
      
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Your Savings Plans</h2>
        <Button className="flex items-center gap-2">
          <Plus size={16} />
          <span>New Plan</span>
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <SavingsPlan 
          title="House Down Payment"
          amount={100000}
          target={500000}
          date="Dec 15, 2024"
          progress={20}
        />
        <SavingsPlan 
          title="Emergency Fund"
          amount={20000}
          target={100000}
          date="Aug 30, 2024"
          progress={20}
        />
        <SavingsPlan 
          title="Vacation"
          amount={5000}
          target={50000}
          date="Nov 1, 2024"
          progress={10}
        />
      </div>
      
      <Tabs defaultValue="fixed">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="fixed">Fixed Deposit</TabsTrigger>
          <TabsTrigger value="flexible">Flexible Savings</TabsTrigger>
          <TabsTrigger value="target">Target Savings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="fixed" className="mt-4">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Create Fixed Deposit</h3>
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input id="amount" type="number" placeholder="Enter amount" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="tenure">Tenure</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select tenure" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 Days (5% p.a)</SelectItem>
                    <SelectItem value="60">60 Days (6% p.a)</SelectItem>
                    <SelectItem value="90">90 Days (7% p.a)</SelectItem>
                    <SelectItem value="180">180 Days (8% p.a)</SelectItem>
                    <SelectItem value="365">365 Days (10% p.a)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="from-account">From Account</Label>
                <Select defaultValue="savings">
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="savings">Savings Account - ₦59,807.37</SelectItem>
                    <SelectItem value="current">Current Account - ₦0.00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="p-3 bg-blue-50 rounded-md">
                <div className="flex justify-between text-sm mb-1">
                  <span>Interest Rate:</span>
                  <span className="font-medium">7% per annum</span>
                </div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Expected Interest:</span>
                  <span className="font-medium">₦1,750.00</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Maturity Date:</span>
                  <span className="font-medium">August 15, 2024</span>
                </div>
              </div>
              
              <Button type="submit" className="w-full">Create Fixed Deposit</Button>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="flexible" className="mt-4">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Flexible Savings</h3>
            <p className="text-gray-600 mb-4">
              Save at your own pace with our flexible savings option. Withdraw anytime with no penalties.
            </p>
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="plan-name">Plan Name</Label>
                <Input id="plan-name" placeholder="E.g. My Flexible Savings" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="initial-deposit">Initial Deposit</Label>
                <Input id="initial-deposit" type="number" placeholder="Enter amount" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="auto-save">Auto-Save (Optional)</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Set up automatic savings" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No automatic savings</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="p-3 bg-blue-50 rounded-md">
                <div className="flex justify-between text-sm">
                  <span>Interest Rate:</span>
                  <span className="font-medium">3.5% per annum</span>
                </div>
              </div>
              
              <Button type="submit" className="w-full">Create Flexible Savings</Button>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="target" className="mt-4">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Target Savings</h3>
            <p className="text-gray-600 mb-4">
              Set a savings goal and timeline. We'll help you stay on track to achieve your target.
            </p>
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="goal-name">Goal Name</Label>
                <Input id="goal-name" placeholder="E.g. New Car, Vacation" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="target-amount">Target Amount</Label>
                <Input id="target-amount" type="number" placeholder="Enter target amount" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="target-date">Target Date</Label>
                <Input id="target-date" type="date" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="initial-deposit">Initial Deposit</Label>
                <Input id="initial-deposit" type="number" placeholder="Enter amount" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="frequency">Contribution Frequency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button type="submit" className="w-full">Create Target Savings</Button>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Savings;
