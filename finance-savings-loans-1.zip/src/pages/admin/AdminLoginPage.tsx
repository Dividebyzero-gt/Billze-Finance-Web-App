import React from 'react';
import { AdminLoginForm } from '@/components/admin/AdminLoginForm';

const AdminLoginPage = () => {
  return <AdminLoginForm />;
};

export default AdminLoginPage;
