import React from 'react';
import { PaymentCallback as PaymentCallbackComponent } from '@/components/payment/PaymentCallback';
import { GlobalLayout } from '@/components/layout/GlobalLayout';

export default function PaymentCallback() {
  return (
    <GlobalLayout>
      <PaymentCallbackComponent />
    </GlobalLayout>
  );
}
