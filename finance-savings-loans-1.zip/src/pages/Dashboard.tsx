import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, ArrowUpRight, CreditCard, DollarSign, LineChart, PiggyBank, Send } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { ServiceMenu } from '@/components/dashboard/ServiceMenu';
import { AccountCard } from '@/components/dashboard/AccountCard';
import { Link } from 'react-router-dom';
import { SEO } from '@/components/SEO';
import { PRIMARY_COLOR } from '@/lib/theme-constants';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <SEO title="Dashboard" description="Manage your finances and view your accounts" />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <AccountCard />
        </div>
        
        <Card className={`bg-gradient-to-br from-${PRIMARY_COLOR.DEFAULT} to-${PRIMARY_COLOR.darker} text-white`}>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Quick Transfer</CardTitle>
            <CardDescription className="text-green-100">Send money instantly</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm text-green-100">Recipient</label>
                <select className={`w-full bg-${PRIMARY_COLOR.dark}/40 border border-green-400/30 rounded-md p-2 text-white placeholder-green-200 text-sm`}>
                  <option value="">Select recipient</option>
                  <option value="john">John Doe</option>
                  <option value="jane">Jane Smith</option>
                  <option value="mike">Mike Johnson</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm text-green-100">Amount</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-green-200">₦</span>
                  <input 
                    type="text" 
                    placeholder="0.00" 
                    className={`w-full bg-${PRIMARY_COLOR.dark}/40 border border-green-400/30 rounded-md p-2 pl-7 text-white placeholder-green-200 text-sm`}
                  />
                </div>
              </div>
              
              <Link to="/transfers">
                <Button className={`w-full bg-white text-${PRIMARY_COLOR.DEFAULT} hover:bg-green-50`}>
                  <Send className="h-4 w-4 mr-2" />
                  Send Money
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <ServiceMenu />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-lg font-medium">Recent Transactions</CardTitle>
              <CardDescription>Your recent financial activities</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { id: 1, type: 'credit', description: 'Salary Payment', amount: '₦250,000', date: 'Today, 9:45 AM', icon: <DollarSign className="h-4 w-4" /> },
                { id: 2, type: 'debit', description: 'Electricity Bill', amount: '₦15,000', date: 'Yesterday, 2:30 PM', icon: <CreditCard className="h-4 w-4" /> },
                { id: 3, type: 'debit', description: 'Grocery Shopping', amount: '₦12,500', date: 'May 10, 11:20 AM', icon: <CreditCard className="h-4 w-4" /> },
                { id: 4, type: 'credit', description: 'Refund from Jumia', amount: '₦5,000', date: 'May 9, 3:15 PM', icon: <DollarSign className="h-4 w-4" /> },
              ].map(transaction => (
                <div key={transaction.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full ${transaction.type === 'credit' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                      {transaction.icon}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{transaction.description}</p>
                      <p className="text-xs text-gray-500">{transaction.date}</p>
                    </div>
                  </div>
                  <p className={`font-medium ${transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                    {transaction.type === 'credit' ? '+' : '-'} {transaction.amount}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Savings Goal</CardTitle>
              <CardDescription>New Car Purchase</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Progress</span>
                  <span className="text-sm font-medium">65%</span>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className={`h-full bg-${PRIMARY_COLOR.DEFAULT} rounded-full`} style={{ width: '65%' }}></div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">₦1,300,000</span>
                  <span className="text-sm text-gray-500">₦2,000,000</span>
                </div>
                <Link to="/savings">
                  <Button variant="outline" className="w-full">
                    <PiggyBank className="h-4 w-4 mr-2" />
                    Add to Savings
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Investment</CardTitle>
              <CardDescription>Your portfolio performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Total Value</span>
                  <span className="font-bold">₦750,000</span>
                </div>
                <div className="flex items-center text-green-600">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  <span className="text-sm font-medium">+5.2% this month</span>
                </div>
                <Link to="/savings">
                  <Button variant="outline" className="w-full">
                    <LineChart className="h-4 w-4 mr-2" />
                    View Portfolio
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
