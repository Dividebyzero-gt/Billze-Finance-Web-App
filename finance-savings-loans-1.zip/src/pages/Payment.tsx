import React from 'react';
import { PaymentForm } from '@/components/payment/PaymentForm';
import { MainLayout } from '@/components/layout/MainLayout';

export default function Payment() {
  const handlePaymentSuccess = (response: any) => {
    console.log('Payment successful:', response);
    // You can implement additional logic here, such as showing a success message
    // or redirecting to another page
  };

  const handlePaymentClose = () => {
    console.log('Payment modal closed');
    // Handle payment cancellation or closure
  };

  return (
    <MainLayout>
      <div className="container mx-auto py-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Make a Payment</h1>
          <div className="bg-white rounded-lg shadow-md p-6">
            <PaymentForm 
              onSuccess={handlePaymentSuccess} 
              onClose={handlePaymentClose}
              title="Complete Your Payment"
              description="Fill in the details below to make a secure payment"
            />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
