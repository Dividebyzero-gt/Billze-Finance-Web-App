import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import App from './App';
import { ThemeProvider } from './components/theme-provider';
import { AuthProvider } from './contexts/AuthContext';
import { SettingsProvider } from './contexts/SettingsContext';
import { AccountProvider } from './contexts/AccountContext';
import { AppProvider } from './contexts/AppContext';

// Import Font Awesome CSS (this is not needed when using the React components directly)
// import '@fortawesome/fontawesome-svg-core/styles.css';

// Import Font Awesome config
import { config } from '@fortawesome/fontawesome-svg-core';

// Import CSS
import './index.css';

// Tell Font Awesome to skip adding CSS automatically since we're handling it
config.autoAddCss = false;

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <HelmetProvider>
      <BrowserRouter>
        <AuthProvider>
          <AccountProvider>
            <AppProvider>
              <SettingsProvider>
                <App />
              </SettingsProvider>
            </AppProvider>
          </AccountProvider>
        </AuthProvider>
      </BrowserRouter>
    </HelmetProvider>
  </React.StrictMode>,
);
