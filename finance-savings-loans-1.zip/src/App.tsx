import { Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import HomePage from '@/pages/HomePage';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import Dashboard from '@/pages/Dashboard';
import NotFound from '@/pages/NotFound';
import Accounts from '@/pages/Accounts';
import Transfers from '@/pages/Transfers';
import Bills from '@/pages/Bills';
import Loans from '@/pages/Loans';
import Savings from '@/pages/Savings';
import Remittance from '@/pages/Remittance';
import Settings from '@/pages/Settings';
import Profile from '@/pages/Profile';
import Payment from '@/pages/Payment';
import PaymentCallback from '@/pages/PaymentCallback';
import Support from '@/pages/Support';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { AuthProvider } from '@/contexts/AuthContext';

function App() {
  return (
    <AuthProvider>
      <ThemeProvider defaultTheme="light" storageKey="billze-theme">
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* Dashboard routes */}
          <Route path="/" element={<DashboardLayout />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="accounts" element={<Accounts />} />
            <Route path="transfers" element={<Transfers />} />
            <Route path="bills" element={<Bills />} />
            <Route path="loans" element={<Loans />} />
            <Route path="savings" element={<Savings />} />
            <Route path="remittance" element={<Remittance />} />
            <Route path="settings" element={<Settings />} />
            <Route path="profile" element={<Profile />} />
            <Route path="payment" element={<Payment />} />
            <Route path="payment/callback" element={<PaymentCallback />} />
            <Route path="support" element={<Support />} />
          </Route>
          
          {/* 404 page */}
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster />
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
