import { supabase } from './supabase';

// Admin authentication functions
export const adminLogin = async (username: string, password: string) => {
  try {
    // In a real application, you would use a secure password hashing mechanism
    // This is simplified for demo purposes using direct password comparison
    const { data, error } = await supabase
      .from('admin_users')
      .select('*')
      .eq('username', username)
      .eq('password_hash', password)
      .eq('is_active', true)
      .single();

    if (error) {
      console.error('Admin login query error:', error);
      return { success: false, message: 'Authentication failed' };
    }
    
    if (data) {
      // Update last login time
      await supabase
        .from('admin_users')
        .update({ last_login: new Date().toISOString() })
        .eq('id', data.id);

      return { success: true, user: data };
    }
    
    return { success: false, message: 'Invalid credentials' };
  } catch (error) {
    console.error('Admin login error:', error);
    return { success: false, message: 'Authentication failed' };
  }
};

// Check if admin is logged in
export const checkAdminAuth = () => {
  const adminAuth = localStorage.getItem('adminAuth');
  if (!adminAuth) return false;
  
  try {
    const auth = JSON.parse(adminAuth);
    // Check if auth is valid and not expired (24 hours)
    const isValid = auth.isAdmin && 
                   (new Date().getTime() - auth.timestamp) < (24 * 60 * 60 * 1000);
    return isValid;
  } catch (e) {
    return false;
  }
};

// Admin logout
export const adminLogout = () => {
  localStorage.removeItem('adminAuth');
};
