// Theme constants for the application

// The primary color from the logo text (blue)
export const PRIMARY_COLOR = {
  light: '#3b82f6', // blue-500
  DEFAULT: '#2563eb', // blue-600
  dark: '#1d4ed8', // blue-700
  darker: '#1e40af', // blue-800
  gradient: {
    from: '#2563eb', // blue-600
    to: '#1e40af', // blue-800
  }
};

// Accent color 
export const ACCENT_COLOR = {
  light: '#93c5fd', // blue-300
  DEFAULT: '#60a5fa', // blue-400
  dark: '#3b82f6', // blue-500
};

// Text colors
export const TEXT_COLORS = {
  primary: '#1e40af', // blue-800
  secondary: '#1d4ed8', // blue-700
  accent: '#60a5fa', // blue-400
  light: '#eff6ff', // blue-50
};

// Background colors
export const BG_COLORS = {
  primary: '#2563eb', // blue-600
  secondary: '#1d4ed8', // blue-700
  light: '#eff6ff', // blue-50
  gradient: 'from-blue-600 to-blue-800',
};
