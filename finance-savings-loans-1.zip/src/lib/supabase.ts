import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://nofmjhxfldsmgliwdjxs.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5vZm1qaHhmbGRzbWdsaXdkanhzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDcwMzU2NzYsImV4cCI6MjA2MjYxMTY3Nn0.d70LiLmn-GsjFcplzIF80r4ax6HAZTMBJ6KoZ3xtY0M';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };