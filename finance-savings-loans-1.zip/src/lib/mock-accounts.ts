import { Account } from '@/types/account';

// Mock accounts data for development
export const mockAccounts: Account[] = [
  {
    id: '1',
    userId: 'user-1',
    accountName: 'Primary Savings',
    accountNumber: '1234567890',
    accountType: 'savings',
    balance: 5432.10,
    currency: 'NGN',
    isDefault: true,
    isMasked: false,
    createdAt: '2023-01-15T12:00:00Z'
  },
  {
    id: '2',
    userId: 'user-1',
    accountName: 'Business Account',
    accountNumber: '0987654321',
    accountType: 'current',
    balance: 12500.75,
    currency: 'NGN',
    isDefault: false,
    isMasked: false,
    createdAt: '2023-03-22T09:30:00Z'
  },
  {
    id: '3',
    userId: 'user-1',
    accountName: 'Dollar Account',
    accountNumber: '5678901234',
    accountType: 'dollar',
    balance: 2500.00,
    currency: 'USD',
    isDefault: false,
    isMasked: true,
    createdAt: '2023-06-10T15:45:00Z'
  }
];

// Helper function to generate a random account number
export const generateAccountNumber = (): string => {
  return Math.floor(1000000000 + Math.random() * 9000000000).toString();
};
