import { supabase } from './supabase';

export const createUser = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        name: 'John Igwilo',
        phone: '+2348012345678',
        account_number: '2023456789',
        account_balance: 5000.00,
        is_active: true
      }
    }
  });
  
  if (error) throw error;
  return data;
};

export const loginUser = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) throw error;
  return data;
};

export const updateAuthContext = async () => {
  // Update the AuthContext with the current user
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};
