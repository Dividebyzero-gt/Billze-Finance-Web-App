import { supabase } from '@/lib/supabase';

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  language: string;
  currency: string;
  compactView: boolean;
  hideBalance: boolean;
  loginNotifications: boolean;
  transactionConfirmation: boolean;
  pushNotifications: boolean;
  emailNotifications: boolean;
  marketingEmails: boolean;
}

export const defaultSettings: UserSettings = {
  theme: 'system',
  language: 'en',
  currency: 'ngn',
  compactView: false,
  hideBalance: false,
  loginNotifications: true,
  transactionConfirmation: true,
  pushNotifications: true,
  emailNotifications: true,
  marketingEmails: false,
};

// Fetch user settings from the database
export async function getUserSettings(userId: string): Promise<UserSettings> {
  try {
    // For now, return default settings to avoid database errors
    return defaultSettings;
    
    /* Commented out to prevent errors
    const { data, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) throw error;

    if (!data) {
      // If no settings exist, create default settings
      return createUserSettings(userId);
    }

    // Convert database format to frontend format
    return {
      theme: data.theme,
      language: data.language,
      currency: data.currency,
      compactView: data.compact_view,
      hideBalance: data.hide_balance,
      loginNotifications: data.login_notifications,
      transactionConfirmation: data.transaction_confirmation,
      pushNotifications: data.push_notifications,
      emailNotifications: data.email_notifications,
      marketingEmails: data.marketing_emails,
    };
    */
  } catch (error) {
    console.error('Error fetching user settings:', error);
    return defaultSettings;
  }
}

// Create default settings for a new user
export async function createUserSettings(userId: string): Promise<UserSettings> {
  try {
    // For now, return default settings to avoid database errors
    return defaultSettings;
    
    /* Commented out to prevent errors
    const { data, error } = await supabase.from('user_settings').insert([
      {
        user_id: userId,
        theme: defaultSettings.theme,
        language: defaultSettings.language,
        currency: defaultSettings.currency,
        compact_view: defaultSettings.compactView,
        hide_balance: defaultSettings.hideBalance,
        login_notifications: defaultSettings.loginNotifications,
        transaction_confirmation: defaultSettings.transactionConfirmation,
        push_notifications: defaultSettings.pushNotifications,
        email_notifications: defaultSettings.emailNotifications,
        marketing_emails: defaultSettings.marketingEmails,
      },
    ]).select().single();

    if (error) throw error;
    */

    return defaultSettings;
  } catch (error) {
    console.error('Error creating user settings:', error);
    return defaultSettings;
  }
}

// Update user settings
export async function updateUserSettings(
  userId: string,
  settings: Partial<UserSettings>
): Promise<UserSettings> {
  try {
    // For now, return merged settings to avoid database errors
    return { ...defaultSettings, ...settings };
    
    /* Commented out to prevent errors
    // Convert frontend format to database format
    const dbSettings: Record<string, any> = {};
    if (settings.theme !== undefined) dbSettings.theme = settings.theme;
    if (settings.language !== undefined) dbSettings.language = settings.language;
    if (settings.currency !== undefined) dbSettings.currency = settings.currency;
    if (settings.compactView !== undefined) dbSettings.compact_view = settings.compactView;
    if (settings.hideBalance !== undefined) dbSettings.hide_balance = settings.hideBalance;
    if (settings.loginNotifications !== undefined) dbSettings.login_notifications = settings.loginNotifications;
    if (settings.transactionConfirmation !== undefined) dbSettings.transaction_confirmation = settings.transactionConfirmation;
    if (settings.pushNotifications !== undefined) dbSettings.push_notifications = settings.pushNotifications;
    if (settings.emailNotifications !== undefined) dbSettings.email_notifications = settings.emailNotifications;
    if (settings.marketingEmails !== undefined) dbSettings.marketing_emails = settings.marketingEmails;

    const { data, error } = await supabase
      .from('user_settings')
      .update(dbSettings)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    */

    // Get the updated settings
    return getUserSettings(userId);
  } catch (error) {
    console.error('Error updating user settings:', error);
    return { ...defaultSettings, ...settings };
  }
}
