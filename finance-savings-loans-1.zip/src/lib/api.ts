import { v4 as uuidv4 } from 'uuid';
import { mockUser, mockTransactions, mockBillPayments, mockSavings, mockLoans } from './mock-data';
import { User, Transaction, BillPayment, Savings, Loan } from '@/types';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock API functions
export const api = {
  // Auth APIs
  login: async (email: string, password: string): Promise<User> => {
    await delay(800);
    if (email && password) {
      return mockUser;
    }
    throw new Error('Invalid credentials');
  },
  
  register: async (name: string, email: string, password: string, phone: string): Promise<User> => {
    await delay(1000);
    if (name && email && password && phone) {
      const newUser: User = {
        ...mockUser,
        id: uuidv4(),
        name,
        email,
        phone,
        accountNumber: Math.floor(1000000000 + Math.random() * 9000000000).toString(),
        accountBalance: 0
      };
      return newUser;
    }
    throw new Error('Invalid registration data');
  },
  
  // Account APIs
  getAccountDetails: async (): Promise<User> => {
    await delay(500);
    return mockUser;
  },
  
  generateAccountNumber: async (): Promise<string> => {
    await delay(700);
    return Math.floor(1000000000 + Math.random() * 9000000000).toString();
  },
  
  // Transaction APIs
  getTransactions: async (): Promise<Transaction[]> => {
    await delay(600);
    return mockTransactions;
  },
  
  // Bill Payment APIs
  getBillPayments: async (): Promise<BillPayment[]> => {
    await delay(600);
    return mockBillPayments;
  },
  
  payBill: async (billType: string, provider: string, amount: number): Promise<BillPayment> => {
    await delay(1000);
    const newBill: BillPayment = {
      id: uuidv4(),
      userId: mockUser.id,
      billType: billType as any,
      provider,
      amount,
      reference: `BILL-${provider.substring(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toISOString(),
      status: 'completed'
    };
    return newBill;
  },
  
  // Savings APIs
  getSavingsPlans: async (): Promise<Savings[]> => {
    await delay(600);
    return mockSavings;
  },
  
  createSavingsPlan: async (planName: string, targetAmount: number, endDate: string): Promise<Savings> => {
    await delay(800);
    const newSavings: Savings = {
      id: uuidv4(),
      userId: mockUser.id,
      planName,
      targetAmount,
      currentAmount: 0,
      startDate: new Date().toISOString(),
      endDate,
      status: 'active'
    };
    return newSavings;
  },
  
  // Loan APIs
  getLoans: async (): Promise<Loan[]> => {
    await delay(600);
    return mockLoans;
  },
  
  applyForLoan: async (amount: number, duration: number): Promise<Loan> => {
    await delay(1000);
    const startDate = new Date();
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + duration);
    
    const newLoan: Loan = {
      id: uuidv4(),
      userId: mockUser.id,
      amount,
      interestRate: 5,
      duration,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      status: 'pending'
    };
    return newLoan;
  },
  
  // Remittance APIs
  sendRemittance: async (amount: number, recipient: string, country: string): Promise<Transaction> => {
    await delay(1200);
    const newTransaction: Transaction = {
      id: uuidv4(),
      userId: mockUser.id,
      amount,
      type: 'debit',
      category: 'remittance',
      description: `Remittance to ${recipient} (${country})`,
      date: new Date().toISOString(),
      status: 'completed'
    };
    return newTransaction;
  }
};
