import { User, Transaction, BillPayment, Savings, Loan } from '@/types';
import { v4 as uuidv4 } from 'uuid';

// Mock user data
export const mockUser: User = {
  id: '1',
  name: 'John Doe',
  email: 'john.doe@example.com',
  phone: '+2348012345678',
  accountNumber: '1234567890',
  accountBalance: 250000, // in Naira
};

// Mock transactions
export const mockTransactions: Transaction[] = [
  {
    id: uuidv4(),
    userId: '1',
    amount: 5000,
    type: 'debit',
    category: 'bill',
    description: 'Electricity Bill Payment',
    date: '2023-09-15T10:30:00',
    status: 'completed',
  },
  {
    id: uuidv4(),
    userId: '1',
    amount: 10000,
    type: 'credit',
    category: 'transfer',
    description: 'Salary Payment',
    date: '2023-09-10T09:15:00',
    status: 'completed',
  },
  {
    id: uuidv4(),
    userId: '1',
    amount: 2000,
    type: 'debit',
    category: 'bill',
    description: 'Internet Subscription',
    date: '2023-09-05T14:20:00',
    status: 'completed',
  },
];

// Mock bill payments
export const mockBillPayments: BillPayment[] = [
  {
    id: uuidv4(),
    userId: '1',
    billType: 'electricity',
    provider: 'EKEDC',
    amount: 5000,
    reference: 'BILL-EKO-123456',
    date: '2023-09-15T10:30:00',
    status: 'completed',
  },
  {
    id: uuidv4(),
    userId: '1',
    billType: 'tv',
    provider: 'DSTV',
    amount: 7500,
    reference: 'BILL-DSTV-789012',
    date: '2023-09-02T16:45:00',
    status: 'completed',
  },
];

// Mock savings plans
export const mockSavings: Savings[] = [
  {
    id: uuidv4(),
    userId: '1',
    planName: 'Vacation Fund',
    targetAmount: 100000,
    currentAmount: 45000,
    startDate: '2023-06-01T00:00:00',
    endDate: '2023-12-31T00:00:00',
    status: 'active',
  },
  {
    id: uuidv4(),
    userId: '1',
    planName: 'Emergency Fund',
    targetAmount: 200000,
    currentAmount: 75000,
    startDate: '2023-01-01T00:00:00',
    endDate: '2023-12-31T00:00:00',
    status: 'active',
  },
];

// Mock loans
export const mockLoans: Loan[] = [
  {
    id: uuidv4(),
    userId: '1',
    amount: 50000,
    interestRate: 5,
    duration: 3, // 3 months
    startDate: '2023-07-15T00:00:00',
    endDate: '2023-10-15T00:00:00',
    status: 'active',
  },
];
