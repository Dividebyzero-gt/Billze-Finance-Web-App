export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  accountNumber?: string;
  accountBalance?: number;
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: 'debit' | 'credit';
  category: 'bill' | 'transfer' | 'savings' | 'loan' | 'remittance';
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'failed';
}

export interface BillPayment {
  id: string;
  userId: string;
  billType: 'electricity' | 'water' | 'internet' | 'tv' | 'education';
  provider: string;
  amount: number;
  reference: string;
  date: string;
  status: 'pending' | 'completed' | 'failed';
}

export interface Savings {
  id: string;
  userId: string;
  planName: string;
  targetAmount: number;
  currentAmount: number;
  startDate: string;
  endDate: string;
  status: 'active' | 'completed' | 'cancelled';
}

export interface Loan {
  id: string;
  userId: string;
  amount: number;
  interestRate: number;
  duration: number; // in months
  startDate: string;
  endDate: string;
  status: 'pending' | 'approved' | 'rejected' | 'active' | 'completed';
}