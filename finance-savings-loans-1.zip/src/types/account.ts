export interface Account {
  id: string;
  userId: string;
  accountName: string;
  accountNumber: string;
  accountType: 'savings' | 'current' | 'fixed deposit' | 'dollar';
  balance: number;
  currency: string;
  isDefault: boolean;
  isMasked: boolean;
  createdAt: string;
}

export interface AccountFormData {
  accountName: string;
  accountType: 'savings' | 'current' | 'fixed deposit' | 'dollar';
  currency: string;
}
